import {
  PDFDocument,
  StandardFonts,
  rgb,
  degrees,
  PDFPage,
} from '@cantoo/pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import * as mammoth from 'mammoth';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import {
  CompressionLevel,
  CropRect,
  EditorPageState,
  ImageFilter,
  ImageItem,
  PageOrientation,
  PageSizePreset,
  PdfAnnotation,
  Point2D,
} from '../types';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.min.mjs',
  import.meta.url
).toString();

export class PasswordRequiredError extends Error {
  constructor(message = 'This PDF is password-protected.') {
    super(message);
    this.name = 'PasswordRequiredError';
  }
}

export class IncorrectPasswordError extends Error {
  constructor(message = 'Incorrect password. Please try again.') {
    super(message);
    this.name = 'IncorrectPasswordError';
  }
}

export const PAGE_SIZE_MAP: Record<'A4' | 'A3' | 'Letter', [number, number]> = {
  A4: [595.28, 841.89],
  A3: [841.89, 1190.55],
  Letter: [612, 792],
};

function resolvePageDimensions(
  preset: PageSizePreset,
  orientation: PageOrientation,
  customW = 595.28,
  customH = 841.89
): [number, number] {
  const [baseW, baseH] =
    preset === 'Custom' ? [customW, customH] : PAGE_SIZE_MAP[preset];
  return orientation === 'landscape'
    ? [Math.max(baseW, baseH), Math.min(baseW, baseH)]
    : [Math.min(baseW, baseH), Math.max(baseW, baseH)];
}

function hexToRgbTuple(hex = '#2563EB'): [number, number, number] {
  const clean = hex.replace('#', '');
  const num = parseInt(
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean,
    16
  );
  if (Number.isNaN(num)) return [0.145, 0.388, 0.922];
  return [((num >> 16) & 255) / 255, ((num >> 8) & 255) / 255, (num & 255) / 255];
}

function sanitizeWinAnsi(text: string): string {
  return text.replace(/[^\x20-\x7E\xA0-\xFF\n]/g, ' ');
}

export async function openPdfJsDoc(bytes: Uint8Array, password?: string) {
  try {
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(bytes),
      password: password || undefined,
    });
    return await loadingTask.promise;
  } catch (err: unknown) {
    const e = err as { name?: string; code?: number; message?: string };
    if (e?.name === 'PasswordException') {
      if (e.code === 2) {
        throw new IncorrectPasswordError();
      }
      throw new PasswordRequiredError();
    }
    throw err;
  }
}

async function closePdfJsDoc(doc: pdfjsLib.PDFDocumentProxy) {
  const proxy = doc as unknown as { destroy?: () => Promise<void>; cleanup?: () => Promise<void> };
  if (typeof proxy.destroy === 'function') {
    await proxy.destroy();
  } else if (typeof proxy.cleanup === 'function') {
    await proxy.cleanup();
  }
}

export async function getPdfPageCount(
  bytes: Uint8Array,
  password?: string
): Promise<{ pageCount: number; isEncrypted: boolean }> {
  try {
    const doc = await openPdfJsDoc(bytes, password);
    const pageCount = doc.numPages;
    await closePdfJsDoc(doc);
    return { pageCount, isEncrypted: Boolean(password) };
  } catch (err) {
    if (err instanceof PasswordRequiredError || err instanceof IncorrectPasswordError) {
      throw err;
    }
    const pdfDoc = await PDFDocument.load(bytes, {
      password,
      ignoreEncryption: true,
    });
    return {
      pageCount: pdfDoc.getPageCount(),
      isEncrypted: pdfDoc.isEncrypted,
    };
  }
}

export async function renderPdfPageToDataUrl(
  bytes: Uint8Array,
  pageIndex: number,
  scale = 1.5,
  password?: string,
  mimeType: 'image/png' | 'image/jpeg' = 'image/png',
  quality = 0.92
): Promise<{ dataUrl: string; width: number; height: number }> {
  const doc = await openPdfJsDoc(bytes, password);
  try {
    const page = await doc.getPage(pageIndex + 1);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(viewport.width));
    canvas.height = Math.max(1, Math.round(viewport.height));
    await page.render({ canvas, viewport }).promise;
    const dataUrl = canvas.toDataURL(mimeType, quality);
    page.cleanup();
    return { dataUrl, width: canvas.width, height: canvas.height };
  } finally {
    await closePdfJsDoc(doc);
  }
}

export async function renderAllPdfThumbnails(
  bytes: Uint8Array,
  scale = 0.45,
  password?: string,
  onProgress?: (pct: number) => void
): Promise<Array<{ dataUrl: string; width: number; height: number }>> {
  const doc = await openPdfJsDoc(bytes, password);
  const results: Array<{ dataUrl: string; width: number; height: number }> = [];
  try {
    const total = doc.numPages;
    for (let i = 1; i <= total; i++) {
      const page = await doc.getPage(i);
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(viewport.width));
      canvas.height = Math.max(1, Math.round(viewport.height));
      await page.render({ canvas, viewport }).promise;
      results.push({
        dataUrl: canvas.toDataURL('image/jpeg', 0.85),
        width: viewport.width / scale,
        height: viewport.height / scale,
      });
      page.cleanup();
      onProgress?.(Math.round((i / total) * 100));
    }
    return results;
  } finally {
    await closePdfJsDoc(doc);
  }
}

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = src;
  });
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

function applyPixelFilter(ctx: CanvasRenderingContext2D, width: number, height: number, filter: ImageFilter) {
  if (filter === 'original') return;
  const imgData = ctx.getImageData(0, 0, width, height);
  const data = imgData.data;

  if (filter === 'grayscale') {
    for (let i = 0; i < data.length; i += 4) {
      const lum = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
      data[i] = lum;
      data[i + 1] = lum;
      data[i + 2] = lum;
    }
  } else if (filter === 'bw') {
    // Document adaptive high-contrast black & white
    let sum = 0;
    const count = data.length / 4;
    const lums = new Uint8Array(count);
    for (let i = 0, p = 0; i < data.length; i += 4, p++) {
      const lum = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
      lums[p] = lum;
      sum += lum;
    }
    const mean = sum / Math.max(1, count);
    const threshold = Math.max(90, Math.min(180, mean * 0.92));
    for (let i = 0, p = 0; i < data.length; i += 4, p++) {
      const v = lums[p] >= threshold ? 255 : 18;
      data[i] = v;
      data[i + 1] = v;
      data[i + 2] = v;
    }
  } else if (filter === 'enhance') {
    // Crisp contrast + brightness boost for color documents
    const contrast = 1.28;
    const brightness = 12;
    for (let i = 0; i < data.length; i += 4) {
      for (let c = 0; c < 3; c++) {
        const val = (data[i + c] - 128) * contrast + 128 + brightness;
        data[i + c] = Math.max(0, Math.min(255, Math.round(val)));
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

export async function processImageTransform(
  originalDataUrl: string,
  rotation: number,
  filter: ImageFilter,
  crop: CropRect
): Promise<{ dataUrl: string; width: number; height: number }> {
  const img = await loadImageElement(originalDataUrl);
  const sx = Math.max(0, Math.round(crop.x * img.naturalWidth));
  const sy = Math.max(0, Math.round(crop.y * img.naturalHeight));
  const sw = Math.max(1, Math.round(crop.w * img.naturalWidth));
  const sh = Math.max(1, Math.round(crop.h * img.naturalHeight));

  const normRot = ((rotation % 360) + 360) % 360;
  const swap = normRot === 90 || normRot === 270;
  const targetW = swap ? sh : sw;
  const targetH = swap ? sw : sh;

  // Cap max dimension at 2400px to handle huge camera images safely without OOM
  const maxDim = 2400;
  const downscale = Math.min(1, maxDim / Math.max(targetW, targetH));
  const outW = Math.max(1, Math.round(targetW * downscale));
  const outH = Math.max(1, Math.round(targetH * downscale));

  const canvas = document.createElement('canvas');
  canvas.width = outW;
  canvas.height = outH;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, outW, outH);

  ctx.save();
  ctx.translate(outW / 2, outH / 2);
  ctx.rotate((normRot * Math.PI) / 180);
  const drawW = swap ? outH : outW;
  const drawH = swap ? outW : outH;
  ctx.drawImage(img, sx, sy, sw, sh, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore();

  applyPixelFilter(ctx, outW, outH, filter);

  return {
    dataUrl: canvas.toDataURL('image/jpeg', 0.9),
    width: outW,
    height: outH,
  };
}

export async function detectDocumentCorners(dataUrl: string): Promise<[Point2D, Point2D, Point2D, Point2D]> {
  const img = await loadImageElement(dataUrl);
  const sampleW = 200;
  const sampleH = Math.max(1, Math.round((img.naturalHeight / img.naturalWidth) * sampleW));
  const canvas = document.createElement('canvas');
  canvas.width = sampleW;
  canvas.height = sampleH;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, sampleW, sampleH);
  const { data } = ctx.getImageData(0, 0, sampleW, sampleH);

  const edge = new Float32Array(sampleW * sampleH);
  const lumAt = (x: number, y: number) => {
    const idx = (y * sampleW + x) * 4;
    return 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
  };

  let maxGrad = 0;
  for (let y = 1; y < sampleH - 1; y++) {
    for (let x = 1; x < sampleW - 1; x++) {
      const gx = Math.abs(lumAt(x + 1, y) - lumAt(x - 1, y));
      const gy = Math.abs(lumAt(x, y + 1) - lumAt(x, y - 1));
      const g = gx + gy;
      edge[y * sampleW + x] = g;
      if (g > maxGrad) maxGrad = g;
    }
  }

  const thresh = Math.max(35, maxGrad * 0.28);
  let tl: Point2D = { x: 0.08, y: 0.08 };
  let tr: Point2D = { x: 0.92, y: 0.08 };
  let br: Point2D = { x: 0.92, y: 0.92 };
  let bl: Point2D = { x: 0.08, y: 0.92 };

  let bestTL = Infinity;
  let bestTR = Infinity;
  let bestBR = Infinity;
  let bestBL = Infinity;

  const marginX = Math.floor(sampleW * 0.04);
  const marginY = Math.floor(sampleH * 0.04);
  for (let y = marginY; y < sampleH - marginY; y++) {
    for (let x = marginX; x < sampleW - marginX; x++) {
      if (edge[y * sampleW + x] < thresh) continue;
      const nx = x / sampleW;
      const ny = y / sampleH;
      const dTL = nx * nx + ny * ny;
      const dTR = (1 - nx) * (1 - nx) + ny * ny;
      const dBR = (1 - nx) * (1 - nx) + (1 - ny) * (1 - ny);
      const dBL = nx * nx + (1 - ny) * (1 - ny);
      if (nx < 0.48 && ny < 0.48 && dTL < bestTL) {
        bestTL = dTL;
        tl = { x: nx, y: ny };
      }
      if (nx > 0.52 && ny < 0.48 && dTR < bestTR) {
        bestTR = dTR;
        tr = { x: nx, y: ny };
      }
      if (nx > 0.52 && ny > 0.52 && dBR < bestBR) {
        bestBR = dBR;
        br = { x: nx, y: ny };
      }
      if (nx < 0.48 && ny > 0.52 && dBL < bestBL) {
        bestBL = dBL;
        bl = { x: nx, y: ny };
      }
    }
  }

  return [tl, tr, br, bl];
}

function solveLinearSystem(A: number[][], b: number[]): number[] {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let i = 0; i < n; i++) {
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(M[k][i]) > Math.abs(M[maxRow][i])) maxRow = k;
    }
    [M[i], M[maxRow]] = [M[maxRow], M[i]];
    const pivot = M[i][i] || 1e-8;
    for (let j = i; j <= n; j++) M[i][j] /= pivot;
    for (let k = 0; k < n; k++) {
      if (k === i) continue;
      const f = M[k][i];
      for (let j = i; j <= n; j++) M[k][j] -= f * M[i][j];
    }
  }
  return M.map((r) => r[n]);
}

export async function perspectiveWarpAndFilter(
  rawDataUrl: string,
  corners: [Point2D, Point2D, Point2D, Point2D],
  filter: ImageFilter
): Promise<{ dataUrl: string; width: number; height: number }> {
  const img = await loadImageElement(rawDataUrl);
  const srcW = img.naturalWidth;
  const srcH = img.naturalHeight;

  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = srcW;
  srcCanvas.height = srcH;
  const srcCtx = srcCanvas.getContext('2d')!;
  srcCtx.drawImage(img, 0, 0);
  const srcPixels = srcCtx.getImageData(0, 0, srcW, srcH).data;

  const pts = corners.map((c) => ({ x: c.x * srcW, y: c.y * srcH }));
  const dist = (a: { x: number; y: number }, b: { x: number; y: number }) =>
    Math.hypot(a.x - b.x, a.y - b.y);

  const topW = dist(pts[0], pts[1]);
  const botW = dist(pts[3], pts[2]);
  const leftH = dist(pts[0], pts[3]);
  const rightH = dist(pts[1], pts[2]);

  let outW = Math.max(100, Math.round(Math.max(topW, botW)));
  let outH = Math.max(100, Math.round(Math.max(leftH, rightH)));
  const maxDim = 1600;
  const scale = Math.min(1, maxDim / Math.max(outW, outH));
  outW = Math.max(1, Math.round(outW * scale));
  outH = Math.max(1, Math.round(outH * scale));

  // Compute homography from destination rectangle (0..outW, 0..outH) -> source quad
  const dstPts = [
    { x: 0, y: 0 },
    { x: outW - 1, y: 0 },
    { x: outW - 1, y: outH - 1 },
    { x: 0, y: outH - 1 },
  ];

  const A: number[][] = [];
  const b: number[] = [];
  for (let i = 0; i < 4; i++) {
    const u = dstPts[i].x;
    const v = dstPts[i].y;
    const x = pts[i].x;
    const y = pts[i].y;
    A.push([u, v, 1, 0, 0, 0, -x * u, -x * v]);
    b.push(x);
    A.push([0, 0, 0, u, v, 1, -y * u, -y * v]);
    b.push(y);
  }
  const h = solveLinearSystem(A, b);
  const H = [...h, 1];

  const outCanvas = document.createElement('canvas');
  outCanvas.width = outW;
  outCanvas.height = outH;
  const outCtx = outCanvas.getContext('2d')!;
  const outImgData = outCtx.createImageData(outW, outH);
  const outPixels = outImgData.data;

  for (let y = 0; y < outH; y++) {
    for (let x = 0; x < outW; x++) {
      const denom = H[6] * x + H[7] * y + H[8];
      const sx = (H[0] * x + H[1] * y + H[2]) / denom;
      const sy = (H[3] * x + H[4] * y + H[5]) / denom;

      const x0 = Math.max(0, Math.min(srcW - 1, Math.floor(sx)));
      const y0 = Math.max(0, Math.min(srcH - 1, Math.floor(sy)));
      const x1 = Math.min(srcW - 1, x0 + 1);
      const y1 = Math.min(srcH - 1, y0 + 1);
      const fx = sx - x0;
      const fy = sy - y0;

      const i00 = (y0 * srcW + x0) * 4;
      const i10 = (y0 * srcW + x1) * 4;
      const i01 = (y1 * srcW + x0) * 4;
      const i11 = (y1 * srcW + x1) * 4;

      const outIdx = (y * outW + x) * 4;
      for (let c = 0; c < 3; c++) {
        const val =
          srcPixels[i00 + c] * (1 - fx) * (1 - fy) +
          srcPixels[i10 + c] * fx * (1 - fy) +
          srcPixels[i01 + c] * (1 - fx) * fy +
          srcPixels[i11 + c] * fx * fy;
        outPixels[outIdx + c] = Math.round(val);
      }
      outPixels[outIdx + 3] = 255;
    }
  }

  outCtx.putImageData(outImgData, 0, 0);
  applyPixelFilter(outCtx, outW, outH, filter);

  return {
    dataUrl: outCanvas.toDataURL('image/jpeg', 0.9),
    width: outW,
    height: outH,
  };
}

function dataUrlToUint8Array(dataUrl: string): Uint8Array {
  const base64 = dataUrl.split(',')[1];
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return bytes;
}

export async function imagesToPdf(
  items: ImageItem[],
  options: {
    pageSize: PageSizePreset;
    orientation: PageOrientation;
    customWidthPt?: number;
    customHeightPt?: number;
    marginPt?: number;
  },
  onProgress?: (pct: number) => void
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const [pageW, pageH] = resolvePageDimensions(
    options.pageSize,
    options.orientation,
    options.customWidthPt,
    options.customHeightPt
  );
  const margin = options.marginPt ?? 24;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const dataUrl = item.processedDataUrl || item.originalDataUrl;
    const bytes = dataUrlToUint8Array(dataUrl);
    const isPng = dataUrl.startsWith('data:image/png');
    const embedded = isPng
      ? await pdfDoc.embedPng(bytes)
      : await pdfDoc.embedJpg(bytes);

    const page = pdfDoc.addPage([pageW, pageH]);
    const availW = Math.max(50, pageW - margin * 2);
    const availH = Math.max(50, pageH - margin * 2);
    const scale = Math.min(availW / embedded.width, availH / embedded.height);
    const drawW = embedded.width * scale;
    const drawH = embedded.height * scale;
    const x = (pageW - drawW) / 2;
    const y = (pageH - drawH) / 2;

    page.drawImage(embedded, { x, y, width: drawW, height: drawH });
    onProgress?.(Math.round(((i + 1) / items.length) * 100));
  }

  return pdfDoc.save({ useObjectStreams: true });
}

export async function saveEditedPdf(
  sourceBytes: Uint8Array,
  pageStates: EditorPageState[],
  annotations: PdfAnnotation[],
  password?: string,
  onProgress?: (pct: number) => void
): Promise<Uint8Array> {
  const srcDoc = await PDFDocument.load(sourceBytes, { password });
  const outDoc = await PDFDocument.create();
  const font = await outDoc.embedFont(StandardFonts.HelveticaBold);

  const indicesToCopy = pageStates.map((p) => p.originalIndex);
  const copiedPages = await outDoc.copyPages(srcDoc, indicesToCopy);

  for (let i = 0; i < pageStates.length; i++) {
    const state = pageStates[i];
    const page = copiedPages[i];
    outDoc.addPage(page);

    if (state.rotation !== 0) {
      const currentRot = page.getRotation().angle;
      page.setRotation(degrees((currentRot + state.rotation) % 360));
    }

    const { width, height } = page.getSize();
    const pageAnnots = annotations.filter((a) => a.pageIndex === state.originalIndex);

    for (const ann of pageAnnots) {
      if (ann.type === 'text' && ann.text) {
        const [r, g, b] = hexToRgbTuple(ann.color || '#1E293B');
        const fontSize = ann.fontSize || 16;
        page.drawText(sanitizeWinAnsi(ann.text), {
          x: ann.x * width,
          y: height - ann.y * height - fontSize,
          size: fontSize,
          font,
          color: rgb(r, g, b),
        });
      } else if (ann.type === 'highlight' && ann.width && ann.height) {
        const [r, g, b] = hexToRgbTuple(ann.color || '#FACC15');
        const rectW = ann.width * width;
        const rectH = ann.height * height;
        page.drawRectangle({
          x: ann.x * width,
          y: height - ann.y * height - rectH,
          width: rectW,
          height: rectH,
          color: rgb(r, g, b),
          opacity: 0.38,
        });
      } else if (ann.type === 'draw' && ann.points && ann.points.length > 1) {
        const [r, g, b] = hexToRgbTuple(ann.color || '#2563EB');
        const thickness = ann.strokeWidth || 2.5;
        for (let k = 1; k < ann.points.length; k++) {
          const p1 = ann.points[k - 1];
          const p2 = ann.points[k];
          page.drawLine({
            start: { x: p1.x * width, y: height - p1.y * height },
            end: { x: p2.x * width, y: height - p2.y * height },
            thickness,
            color: rgb(r, g, b),
          });
        }
      } else if ((ann.type === 'image' || ann.type === 'signature') && ann.imageDataUrl) {
        const imgBytes = dataUrlToUint8Array(ann.imageDataUrl);
        const embedded = ann.imageDataUrl.startsWith('data:image/png')
          ? await outDoc.embedPng(imgBytes)
          : await outDoc.embedJpg(imgBytes);
        const boxW = (ann.width || 0.25) * width;
        const boxH = (ann.height || 0.12) * height;
        page.drawImage(embedded, {
          x: ann.x * width,
          y: height - ann.y * height - boxH,
          width: boxW,
          height: boxH,
        });
      }
    }

    onProgress?.(Math.round(((i + 1) / pageStates.length) * 100));
  }

  return outDoc.save({ useObjectStreams: true });
}

export async function compressPdf(
  sourceBytes: Uint8Array,
  level: CompressionLevel,
  password?: string,
  onProgress?: (pct: number) => void
): Promise<{
  bytes: Uint8Array;
  originalSize: number;
  compressedSize: number;
  pageCount: number;
}> {
  const originalSize = sourceBytes.byteLength;
  const presets: Record<CompressionLevel, { scale: number; quality: number }> = {
    low: { scale: 1.5, quality: 0.82 },
    medium: { scale: 1.15, quality: 0.62 },
    high: { scale: 0.82, quality: 0.42 },
  };
  const cfg = presets[level];

  const doc = await openPdfJsDoc(sourceBytes, password);
  const outDoc = await PDFDocument.create();
  const total = doc.numPages;

  try {
    for (let i = 1; i <= total; i++) {
      const page = await doc.getPage(i);
      const baseViewport = page.getViewport({ scale: 1 });
      const renderViewport = page.getViewport({ scale: cfg.scale });

      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(renderViewport.width));
      canvas.height = Math.max(1, Math.round(renderViewport.height));
      await page.render({ canvas, viewport: renderViewport }).promise;

      const jpegDataUrl = canvas.toDataURL('image/jpeg', cfg.quality);
      const jpgBytes = dataUrlToUint8Array(jpegDataUrl);
      const embedded = await outDoc.embedJpg(jpgBytes);

      const newPage = outDoc.addPage([baseViewport.width, baseViewport.height]);
      newPage.drawImage(embedded, {
        x: 0,
        y: 0,
        width: baseViewport.width,
        height: baseViewport.height,
      });
      page.cleanup();
      onProgress?.(Math.round((i / total) * 90));
    }
  } finally {
    await closePdfJsDoc(doc);
  }

  const rasterBytes = await outDoc.save({ useObjectStreams: true });

  // Also test structural object-stream optimization; if the PDF is tiny pure vector text and rasterizing made it larger, keep the smaller valid output
  let bestBytes = rasterBytes;
  try {
    const srcPdf = await PDFDocument.load(sourceBytes, { password });
    const structuralBytes = await srcPdf.save({ useObjectStreams: true });
    if (structuralBytes.byteLength < bestBytes.byteLength && level === 'low') {
      bestBytes = structuralBytes;
    } else if (rasterBytes.byteLength >= originalSize && structuralBytes.byteLength < rasterBytes.byteLength) {
      bestBytes = structuralBytes;
    }
  } catch {
    // ignore fallback if encrypted or non-standard
  }

  onProgress?.(100);
  return {
    bytes: bestBytes,
    originalSize,
    compressedSize: bestBytes.byteLength,
    pageCount: total,
  };
}

export async function mergePdfs(
  sources: Array<{ bytes: Uint8Array; selectedPages: number[]; password?: string }>,
  onProgress?: (pct: number) => void
): Promise<Uint8Array> {
  const outDoc = await PDFDocument.create();
  for (let i = 0; i < sources.length; i++) {
    const src = sources[i];
    if (src.selectedPages.length === 0) continue;
    const loaded = await PDFDocument.load(src.bytes, { password: src.password });
    const copied = await outDoc.copyPages(loaded, src.selectedPages);
    for (const p of copied) outDoc.addPage(p);
    onProgress?.(Math.round(((i + 1) / sources.length) * 100));
  }
  return outDoc.save({ useObjectStreams: true });
}

export function parsePageRangeGroups(input: string, totalPages: number): number[][] {
  const groups: number[][] = [];
  const parts = input
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  for (const part of parts) {
    if (part.includes('-')) {
      const [startStr, endStr] = part.split('-').map((s) => s.trim());
      const start = Math.max(1, Math.min(totalPages, parseInt(startStr, 10)));
      const end = Math.max(1, Math.min(totalPages, parseInt(endStr, 10)));
      if (!Number.isNaN(start) && !Number.isNaN(end)) {
        const lo = Math.min(start, end);
        const hi = Math.max(start, end);
        const arr: number[] = [];
        for (let p = lo; p <= hi; p++) arr.push(p - 1);
        if (arr.length) groups.push(arr);
      }
    } else {
      const p = parseInt(part, 10);
      if (!Number.isNaN(p) && p >= 1 && p <= totalPages) {
        groups.push([p - 1]);
      }
    }
  }
  return groups;
}

export async function splitPdf(
  sourceBytes: Uint8Array,
  groups: number[][],
  baseName: string,
  password?: string,
  onProgress?: (pct: number) => void
): Promise<Array<{ name: string; bytes: Uint8Array; pageCount: number }>> {
  const srcDoc = await PDFDocument.load(sourceBytes, { password });
  const results: Array<{ name: string; bytes: Uint8Array; pageCount: number }> = [];
  const cleanBase = baseName.replace(/\.pdf$/i, '');

  for (let i = 0; i < groups.length; i++) {
    const indices = groups[i];
    if (indices.length === 0) continue;
    const outDoc = await PDFDocument.create();
    const copied = await outDoc.copyPages(srcDoc, indices);
    for (const p of copied) outDoc.addPage(p);
    const bytes = await outDoc.save({ useObjectStreams: true });
    results.push({
      name: `${cleanBase}_part${i + 1}.pdf`,
      bytes,
      pageCount: indices.length,
    });
    onProgress?.(Math.round(((i + 1) / groups.length) * 100));
  }

  return results;
}

export async function pdfToImages(
  sourceBytes: Uint8Array,
  format: 'jpeg' | 'png',
  scale = 2,
  password?: string,
  onProgress?: (pct: number) => void
): Promise<Array<{ name: string; blob: Blob; dataUrl: string }>> {
  const doc = await openPdfJsDoc(sourceBytes, password);
  const results: Array<{ name: string; blob: Blob; dataUrl: string }> = [];
  const mime = format === 'jpeg' ? 'image/jpeg' : 'image/png';
  const ext = format === 'jpeg' ? 'jpg' : 'png';

  try {
    const total = doc.numPages;
    for (let i = 1; i <= total; i++) {
      const page = await doc.getPage(i);
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(viewport.width));
      canvas.height = Math.max(1, Math.round(viewport.height));
      await page.render({ canvas, viewport }).promise;

      const dataUrl = canvas.toDataURL(mime, 0.92);
      const blob = await new Promise<Blob>((resolve) =>
        canvas.toBlob((b) => resolve(b || new Blob()), mime, 0.92)
      );
      results.push({ name: `page_${i}.${ext}`, blob, dataUrl });
      page.cleanup();
      onProgress?.(Math.round((i / total) * 100));
    }
    return results;
  } finally {
    await closePdfJsDoc(doc);
  }
}

export async function bundleImagesAsZip(
  images: Array<{ name: string; blob: Blob }>
): Promise<Uint8Array> {
  const zip = new JSZip();
  for (const img of images) {
    zip.file(img.name, img.blob);
  }
  return zip.generateAsync({ type: 'uint8array' });
}

interface TextBlock {
  text: string;
  isHeading?: boolean;
  level?: number;
}

function wrapTextLines(
  text: string,
  maxWidth: number,
  font: { widthOfTextAtSize: (t: string, s: number) => number },
  fontSize: number
): string[] {
  const safe = sanitizeWinAnsi(text);
  const words = safe.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  const lines: string[] = [];
  let current = words[0];

  for (let i = 1; i < words.length; i++) {
    const candidate = `${current} ${words[i]}`;
    if (font.widthOfTextAtSize(candidate, fontSize) <= maxWidth) {
      current = candidate;
    } else {
      lines.push(current);
      current = words[i];
    }
  }
  lines.push(current);
  return lines;
}

async function renderBlocksToPdf(
  blocks: TextBlock[],
  pageSize: PageSizePreset,
  orientation: PageOrientation,
  onProgress?: (pct: number) => void
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const [pageW, pageH] = resolvePageDimensions(pageSize, orientation);
  const marginX = 50;
  const marginY = 54;
  const maxWidth = pageW - marginX * 2;

  let page: PDFPage = pdfDoc.addPage([pageW, pageH]);
  let cursorY = pageH - marginY;

  for (let idx = 0; idx < blocks.length; idx++) {
    const block = blocks[idx];
    const trimmed = block.text.trim();
    if (!trimmed) {
      cursorY -= 10;
      continue;
    }

    const isHeading = Boolean(block.isHeading);
    const fontSize = isHeading ? (block.level === 1 ? 18 : 14) : 11;
    const lineHeight = fontSize * 1.45;
    const font = isHeading ? bold : regular;
    const lines = wrapTextLines(trimmed, maxWidth, font, fontSize);

    if (isHeading) cursorY -= 6;

    for (const line of lines) {
      if (cursorY - lineHeight < marginY) {
        page = pdfDoc.addPage([pageW, pageH]);
        cursorY = pageH - marginY;
      }
      page.drawText(line, {
        x: marginX,
        y: cursorY - fontSize,
        size: fontSize,
        font,
        color: isHeading ? rgb(0.06, 0.14, 0.35) : rgb(0.12, 0.16, 0.23),
      });
      cursorY -= lineHeight;
    }

    cursorY -= isHeading ? 6 : 5;
    onProgress?.(Math.round(((idx + 1) / Math.max(1, blocks.length)) * 100));
  }

  return pdfDoc.save({ useObjectStreams: true });
}

export async function wordToPdf(
  arrayBuffer: ArrayBuffer,
  pageSize: PageSizePreset = 'A4',
  orientation: PageOrientation = 'portrait',
  onProgress?: (pct: number) => void
): Promise<{ bytes: Uint8Array; previewHtml: string }> {
  onProgress?.(20);
  const htmlResult = await mammoth.convertToHtml({ arrayBuffer });
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlResult.value, 'text/html');
  const blocks: TextBlock[] = [];

  doc.body.querySelectorAll('h1,h2,h3,h4,p,li,tr').forEach((el) => {
    const tag = el.tagName.toLowerCase();
    const text = el.textContent?.trim() || '';
    if (!text) return;
    if (tag.startsWith('h')) {
      blocks.push({ text, isHeading: true, level: parseInt(tag[1], 10) || 2 });
    } else if (tag === 'li') {
      blocks.push({ text: `• ${text}` });
    } else if (tag === 'tr') {
      const cells = Array.from(el.querySelectorAll('th,td'))
        .map((c) => c.textContent?.trim() || '')
        .join('   |   ');
      if (cells) blocks.push({ text: cells });
    } else {
      blocks.push({ text });
    }
  });

  if (blocks.length === 0) {
    const raw = await mammoth.extractRawText({ arrayBuffer });
    raw.value
      .split('\n')
      .map((t) => t.trim())
      .filter(Boolean)
      .forEach((t) => blocks.push({ text: t }));
  }

  const bytes = await renderBlocksToPdf(blocks, pageSize, orientation, onProgress);
  return { bytes, previewHtml: htmlResult.value };
}

export async function excelToPdf(
  arrayBuffer: ArrayBuffer,
  pageSize: PageSizePreset = 'A4',
  orientation: PageOrientation = 'landscape',
  onProgress?: (pct: number) => void
): Promise<{ bytes: Uint8Array; sheetNames: string[]; previewRows: string[][] }> {
  onProgress?.(15);
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetNames = workbook.SheetNames;
  const pdfDoc = await PDFDocument.create();
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const [pageW, pageH] = resolvePageDimensions(pageSize, orientation);
  const margin = 36;
  const usableW = pageW - margin * 2;

  let previewRows: string[][] = [];

  for (let sIdx = 0; sIdx < sheetNames.length; sIdx++) {
    const name = sheetNames[sIdx];
    const sheet = workbook.Sheets[name];
    const rows = XLSX.utils.sheet_to_json<string[]>(sheet, {
      header: 1,
      raw: false,
      defval: '',
    });

    if (sIdx === 0) previewRows = rows.slice(0, 12);
    if (rows.length === 0) continue;

    const colCount = Math.max(1, Math.min(10, Math.max(...rows.map((r) => r.length))));
    const colW = usableW / colCount;
    const rowH = 20;

    let page = pdfDoc.addPage([pageW, pageH]);
    let cursorY = pageH - margin;

    page.drawText(sanitizeWinAnsi(name), {
      x: margin,
      y: cursorY - 14,
      size: 13,
      font: bold,
      color: rgb(0.145, 0.388, 0.922),
    });
    cursorY -= 26;

    for (let rIdx = 0; rIdx < rows.length; rIdx++) {
      if (cursorY - rowH < margin) {
        page = pdfDoc.addPage([pageW, pageH]);
        cursorY = pageH - margin;
      }

      const row = rows[rIdx];
      const isHeader = rIdx === 0;

      if (isHeader) {
        page.drawRectangle({
          x: margin,
          y: cursorY - rowH,
          width: usableW,
          height: rowH,
          color: rgb(0.93, 0.96, 1),
        });
      }

      for (let c = 0; c < colCount; c++) {
        const cellX = margin + c * colW;
        page.drawRectangle({
          x: cellX,
          y: cursorY - rowH,
          width: colW,
          height: rowH,
          borderColor: rgb(0.84, 0.87, 0.92),
          borderWidth: 0.6,
        });

        const rawVal = sanitizeWinAnsi(String(row[c] ?? ''));
        const maxChars = Math.max(4, Math.floor(colW / 5.4));
        const clipped =
          rawVal.length > maxChars ? `${rawVal.slice(0, maxChars - 1)}…` : rawVal;

        page.drawText(clipped, {
          x: cellX + 4,
          y: cursorY - 14,
          size: 8.5,
          font: isHeader ? bold : regular,
          color: rgb(0.1, 0.14, 0.22),
        });
      }

      cursorY -= rowH;
    }

    onProgress?.(Math.round(((sIdx + 1) / sheetNames.length) * 100));
  }

  if (pdfDoc.getPageCount() === 0) {
    pdfDoc.addPage([pageW, pageH]);
  }

  const bytes = await pdfDoc.save({ useObjectStreams: true });
  return { bytes, sheetNames, previewRows };
}

export async function pptToPdf(
  arrayBuffer: ArrayBuffer,
  onProgress?: (pct: number) => void
): Promise<{ bytes: Uint8Array; slideCount: number }> {
  const zip = await JSZip.loadAsync(arrayBuffer);
  const slideFiles = Object.keys(zip.files)
    .filter((k) => /^ppt\/slides\/slide\d+\.xml$/i.test(k))
    .sort((a, b) => {
      const na = parseInt(a.match(/slide(\d+)\.xml/i)?.[1] || '0', 10);
      const nb = parseInt(b.match(/slide(\d+)\.xml/i)?.[1] || '0', 10);
      return na - nb;
    });

  const pdfDoc = await PDFDocument.create();
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  // 16:9 widescreen slide in points
  const slideW = 960;
  const slideH = 540;
  const parser = new DOMParser();

  for (let i = 0; i < slideFiles.length; i++) {
    const xmlStr = await zip.files[slideFiles[i]].async('string');
    const xmlDoc = parser.parseFromString(xmlStr, 'application/xml');
    const paragraphs = Array.from(xmlDoc.getElementsByTagName('a:p'))
      .map((p) =>
        Array.from(p.getElementsByTagName('a:t'))
          .map((t) => t.textContent || '')
          .join('')
          .trim()
      )
      .filter(Boolean);

    const page = pdfDoc.addPage([slideW, slideH]);
    // Crisp blue accent top bar on slide
    page.drawRectangle({
      x: 0,
      y: slideH - 12,
      width: slideW,
      height: 12,
      color: rgb(0.145, 0.388, 0.922),
    });

    page.drawText(`Slide ${i + 1}`, {
      x: 56,
      y: slideH - 42,
      size: 11,
      font: regular,
      color: rgb(0.45, 0.52, 0.62),
    });

    let y = slideH - 86;
    paragraphs.forEach((text, pIdx) => {
      const isTitle = pIdx === 0;
      const fontSize = isTitle ? 26 : 15;
      const font = isTitle ? bold : regular;
      const lines = wrapTextLines(isTitle ? text : `• ${text}`, slideW - 112, font, fontSize);
      for (const line of lines) {
        if (y < 48) break;
        page.drawText(line, {
          x: 56,
          y,
          size: fontSize,
          font,
          color: isTitle ? rgb(0.06, 0.14, 0.35) : rgb(0.18, 0.23, 0.32),
        });
        y -= fontSize * 1.45;
      }
      y -= isTitle ? 14 : 6;
    });

    onProgress?.(Math.round(((i + 1) / Math.max(1, slideFiles.length)) * 100));
  }

  if (pdfDoc.getPageCount() === 0) {
    const p = pdfDoc.addPage([slideW, slideH]);
    p.drawText('Empty Presentation', { x: 60, y: slideH - 80, size: 22, font: bold });
  }

  const bytes = await pdfDoc.save({ useObjectStreams: true });
  return { bytes, slideCount: slideFiles.length };
}

export async function pdfToWord(
  sourceBytes: Uint8Array,
  title: string,
  password?: string,
  onProgress?: (pct: number) => void
): Promise<{ blob: Blob; extractedText: string }> {
  const doc = await openPdfJsDoc(sourceBytes, password);
  const children: Paragraph[] = [
    new Paragraph({
      text: title.replace(/\.pdf$/i, ''),
      heading: HeadingLevel.HEADING_1,
    }),
  ];

  const allText: string[] = [];

  try {
    const total = doc.numPages;
    for (let i = 1; i <= total; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();

      // Group text items by Y coordinate into readable lines
      const linesMap = new Map<number, Array<{ x: number; str: string }>>();
      for (const item of content.items) {
        if (!('str' in item)) continue;
        const text = item.str;
        if (!text.trim()) continue;
        const y = Math.round(item.transform[5] / 4) * 4;
        const x = item.transform[4];
        const bucket = linesMap.get(y) || [];
        bucket.push({ x, str: text });
        linesMap.set(y, bucket);
      }

      const sortedYs = Array.from(linesMap.keys()).sort((a, b) => b - a);
      if (total > 1) {
        children.push(
          new Paragraph({
            text: `Page ${i}`,
            heading: HeadingLevel.HEADING_2,
          })
        );
      }

      const pageLines: string[] = [];
      for (const y of sortedYs) {
        const lineStr = linesMap
          .get(y)!
          .sort((a, b) => a.x - b.x)
          .map((t) => t.str)
          .join(' ')
          .replace(/\s+/g, ' ')
          .trim();
        if (lineStr) {
          pageLines.push(lineStr);
          children.push(
            new Paragraph({
              children: [new TextRun(lineStr)],
            })
          );
        }
      }

      allText.push(pageLines.join('\n'));
      page.cleanup();
      onProgress?.(Math.round((i / total) * 90));
    }
  } finally {
    await closePdfJsDoc(doc);
  }

  const wordDoc = new Document({
    sections: [{ children }],
  });
  const blob = await Packer.toBlob(wordDoc);
  onProgress?.(100);
  return { blob, extractedText: allText.join('\n\n') };
}

export async function protectPdfWithPassword(
  sourceBytes: Uint8Array,
  userPassword: string,
  ownerPassword?: string,
  permissions: {
    printing?: boolean;
    copying?: boolean;
    modifying?: boolean;
  } = { printing: true, copying: false, modifying: false }
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(sourceBytes);
  pdfDoc.encrypt({
    userPassword,
    ownerPassword: ownerPassword || userPassword,
    algorithm: 'AES-256',
    permissions: {
      printing: permissions.printing ? 'highResolution' : false,
      copying: Boolean(permissions.copying),
      modifying: Boolean(permissions.modifying),
      annotating: Boolean(permissions.modifying),
      fillingForms: true,
      contentAccessibility: true,
      documentAssembly: Boolean(permissions.modifying),
    },
  });
  return pdfDoc.save();
}

export async function unlockPdfWithPassword(
  sourceBytes: Uint8Array,
  password: string
): Promise<{ bytes: Uint8Array; pageCount: number }> {
  try {
    const srcDoc = await PDFDocument.load(sourceBytes, { password });
    const outDoc = await PDFDocument.create();
    const indices = srcDoc.getPageIndices();
    const copied = await outDoc.copyPages(srcDoc, indices);
    for (const p of copied) outDoc.addPage(p);
    const bytes = await outDoc.save({ useObjectStreams: true });
    return { bytes, pageCount: outDoc.getPageCount() };
  } catch (err) {
    // Also verify via pdfjs-dist in case encryption uses a cipher where pdf-lib fails
    const doc = await openPdfJsDoc(sourceBytes, password);
    const total = doc.numPages;
    const outDoc = await PDFDocument.create();
    try {
      for (let i = 1; i <= total; i++) {
        const page = await doc.getPage(i);
        const vp1 = page.getViewport({ scale: 1 });
        const vp = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(vp.width);
        canvas.height = Math.round(vp.height);
        await page.render({ canvas, viewport: vp }).promise;
        const jpgBytes = dataUrlToUint8Array(canvas.toDataURL('image/jpeg', 0.94));
        const embedded = await outDoc.embedJpg(jpgBytes);
        const outPage = outDoc.addPage([vp1.width, vp1.height]);
        outPage.drawImage(embedded, { x: 0, y: 0, width: vp1.width, height: vp1.height });
        page.cleanup();
      }
      const bytes = await outDoc.save({ useObjectStreams: true });
      return { bytes, pageCount: total };
    } finally {
      await closePdfJsDoc(doc);
    }
  }
}
