import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  BannerAdPosition,
  BannerAdSize,
} from '@capacitor-community/admob';
import { AppSettings } from '../types';

export const ADMOB_TEST_IDS = {
  appId: 'ca-app-pub-3940256099942544~3347511713',
  banner: 'ca-app-pub-3940256099942544/6300978111',
  interstitial: 'ca-app-pub-3940256099942544/1033173712',
  rewarded: 'ca-app-pub-3940256099942544/5224354917',
} as const;

export const ADMOB_APP_ID_REGEX = /^ca-app-pub-\d{16}~\d{10}$/;
export const ADMOB_UNIT_ID_REGEX = /^ca-app-pub-\d{16}\/\d{10}$/;

export function isValidAdMobAppId(id: string): boolean {
  return ADMOB_APP_ID_REGEX.test(id.trim());
}

export function isValidAdMobUnitId(id: string): boolean {
  return ADMOB_UNIT_ID_REGEX.test(id.trim());
}

export function isTestAdMobId(id: string): boolean {
  return id.trim().startsWith('ca-app-pub-3940256099942544');
}

export interface ResolvedAdMobConfig {
  isTesting: boolean;
  hasProductionIds: boolean;
  appId: string;
  bannerId: string;
  interstitialId: string;
  rewardedId: string;
}

export function resolveAdMobConfig(settings: AppSettings): ResolvedAdMobConfig {
  const prodAppId = (settings.admobAppId || import.meta.env.VITE_ADMOB_APP_ID || '').trim();
  const prodBanner = (settings.admobBannerId || import.meta.env.VITE_ADMOB_BANNER_ID || '').trim();
  const prodInterstitial = (settings.admobInterstitialId || import.meta.env.VITE_ADMOB_INTERSTITIAL_ID || '').trim();
  const prodRewarded = (settings.admobRewardedId || import.meta.env.VITE_ADMOB_REWARDED_ID || '').trim();

  const hasValidProdBanner = isValidAdMobUnitId(prodBanner) && !isTestAdMobId(prodBanner);
  const hasValidProdInterstitial = isValidAdMobUnitId(prodInterstitial) && !isTestAdMobId(prodInterstitial);
  const hasValidProdRewarded = isValidAdMobUnitId(prodRewarded) && !isTestAdMobId(prodRewarded);

  const useProduction =
    settings.admobMode === 'production' &&
    (hasValidProdBanner || hasValidProdInterstitial || hasValidProdRewarded);

  return {
    isTesting: !useProduction,
    hasProductionIds: hasValidProdBanner || hasValidProdInterstitial || hasValidProdRewarded,
    appId: useProduction && isValidAdMobAppId(prodAppId) ? prodAppId : ADMOB_TEST_IDS.appId,
    bannerId: useProduction && hasValidProdBanner ? prodBanner : ADMOB_TEST_IDS.banner,
    interstitialId:
      useProduction && hasValidProdInterstitial ? prodInterstitial : ADMOB_TEST_IDS.interstitial,
    rewardedId: useProduction && hasValidProdRewarded ? prodRewarded : ADMOB_TEST_IDS.rewarded,
  };
}

let initializedTestingMode: boolean | null = null;

export function isNativeAndroidOrIOS(): boolean {
  return Capacitor.isNativePlatform();
}

export async function initAdMob(isTesting: boolean): Promise<void> {
  if (initializedTestingMode === isTesting) return;
  if (!isNativeAndroidOrIOS()) {
    initializedTestingMode = isTesting;
    return;
  }
  try {
    await AdMob.initialize({
      initializeForTesting: isTesting,
    });
    initializedTestingMode = isTesting;
  } catch {
    // ignore on unsupported platforms
  }
}

export async function showNativeBanner(config: ResolvedAdMobConfig): Promise<boolean> {
  if (!isNativeAndroidOrIOS()) return false;
  try {
    await initAdMob(config.isTesting);
    await AdMob.showBanner({
      adId: config.bannerId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      isTesting: config.isTesting,
    });
    return true;
  } catch {
    return false;
  }
}

export async function hideNativeBanner(): Promise<void> {
  if (!isNativeAndroidOrIOS()) return;
  try {
    await AdMob.hideBanner();
  } catch {
    // ignore
  }
}

export async function triggerInterstitialAd(
  config: ResolvedAdMobConfig,
  onWebPreview: () => void
): Promise<void> {
  if (!isNativeAndroidOrIOS()) {
    onWebPreview();
    return;
  }
  try {
    await initAdMob(config.isTesting);
    await AdMob.prepareInterstitial({
      adId: config.interstitialId,
      isTesting: config.isTesting,
    });
    await AdMob.showInterstitial();
  } catch {
    onWebPreview();
  }
}

export async function triggerRewardedAd(
  config: ResolvedAdMobConfig,
  onWebPreview: () => void,
  onRewardEarned?: () => void
): Promise<void> {
  if (!isNativeAndroidOrIOS()) {
    onWebPreview();
    return;
  }
  try {
    await initAdMob(config.isTesting);
    await AdMob.prepareRewardVideoAd({
      adId: config.rewardedId,
      isTesting: config.isTesting,
    });
    const reward = await AdMob.showRewardVideoAd();
    if (reward) {
      onRewardEarned?.();
    }
  } catch {
    onWebPreview();
  }
}
