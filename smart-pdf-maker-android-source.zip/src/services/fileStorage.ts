import { AppSettings, StoredFile } from '../types';

const DB_NAME = 'SmartPDFMakerDB';
const DB_VERSION = 1;
const STORE_FILES = 'files';
const SETTINGS_KEY = 'smart_pdf_maker_settings_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  language: 'en',
  defaultPageSize: 'A4',
  defaultOrientation: 'portrait',
  defaultCompression: 'medium',
  storagePreference: 'device-indexeddb',
  admobEnabled: true,
  admobMode: 'production',
  admobAppId: import.meta.env.VITE_ADMOB_APP_ID || '',
  admobBannerId: import.meta.env.VITE_ADMOB_BANNER_ID || '',
  admobInterstitialId: import.meta.env.VITE_ADMOB_INTERSTITIAL_ID || '',
  admobRewardedId: import.meta.env.VITE_ADMOB_REWARDED_ID || '',
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore storage quota errors
  }
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_FILES)) {
        const store = db.createObjectStore(STORE_FILES, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('lastOpenedAt', 'lastOpenedAt', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveFileToLocalStore(
  file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'> & { id?: string }
): Promise<StoredFile> {
  const db = await openDB();
  const now = Date.now();
  const record: StoredFile = {
    id: file.id || `doc_${now}_${Math.random().toString(36).slice(2, 8)}`,
    name: file.name,
    size: file.data.byteLength,
    pageCount: file.pageCount,
    category: file.category,
    mimeType: file.mimeType,
    data: file.data,
    createdAt: now,
    lastOpenedAt: now,
    isEncrypted: file.isEncrypted,
    sourceTool: file.sourceTool,
  };

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readwrite');
    tx.objectStore(STORE_FILES).put(record);
    tx.oncomplete = () => resolve(record);
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAllStoredFiles(): Promise<StoredFile[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readonly');
    const req = tx.objectStore(STORE_FILES).getAll();
    req.onsuccess = () => {
      const items = (req.result as StoredFile[]).sort((a, b) => b.lastOpenedAt - a.lastOpenedAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error);
  });
}

export async function touchStoredFile(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readwrite');
    const store = tx.objectStore(STORE_FILES);
    const req = store.get(id);
    req.onsuccess = () => {
      const item = req.result as StoredFile | undefined;
      if (item) {
        item.lastOpenedAt = Date.now();
        store.put(item);
      }
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function renameStoredFile(id: string, newName: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readwrite');
    const store = tx.objectStore(STORE_FILES);
    const req = store.get(id);
    req.onsuccess = () => {
      const item = req.result as StoredFile | undefined;
      if (item) {
        item.name = newName;
        store.put(item);
      }
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteStoredFile(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readwrite');
    tx.objectStore(STORE_FILES).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllStoredFiles(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FILES, 'readwrite');
    tx.objectStore(STORE_FILES).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, i);
  return `${value >= 10 || i === 0 ? value.toFixed(0) : value.toFixed(2)} ${units[i]}`;
}

export function formatRelativeDate(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(ts).toLocaleDateString();
}

export async function saveBytesToDevice(
  bytes: Uint8Array,
  fileName: string,
  mimeType = 'application/pdf'
): Promise<'saved-picker' | 'downloaded' | 'cancelled'> {
  const copy = new Uint8Array(bytes);
  const blob = new Blob([copy.buffer], { type: mimeType });

  // Use File System Access API (Android Storage Access Framework equivalent on web) when available
  const win = window as unknown as {
    showSaveFilePicker?: (opts: {
      suggestedName: string;
      types?: Array<{ description: string; accept: Record<string, string[]> }>;
    }) => Promise<{ createWritable: () => Promise<{ write: (b: Blob) => Promise<void>; close: () => Promise<void> }> }>;
  };

  if (typeof win.showSaveFilePicker === 'function') {
    try {
      const ext = fileName.includes('.') ? `.${fileName.split('.').pop()}` : '.pdf';
      const handle = await win.showSaveFilePicker({
        suggestedName: fileName,
        types: [
          {
            description: mimeType === 'application/pdf' ? 'PDF Document' : 'Document File',
            accept: { [mimeType]: [ext] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return 'saved-picker';
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        return 'cancelled';
      }
      // Fall back to standard download if picker is blocked inside iframe
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  return 'downloaded';
}

export async function shareFileNative(
  bytes: Uint8Array,
  fileName: string,
  mimeType = 'application/pdf'
): Promise<'shared' | 'fallback-downloaded'> {
  const copy = new Uint8Array(bytes);
  const file = new File([copy.buffer], fileName, { type: mimeType });

  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        title: fileName,
        text: `Shared via Smart PDF Maker`,
        files: [file],
      });
      return 'shared';
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        return 'shared';
      }
    }
  }

  await saveBytesToDevice(bytes, fileName, mimeType);
  return 'fallback-downloaded';
}
