import React, { useEffect, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Download,
  Edit3,
  Loader2,
  Share2,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { StoredFile } from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  getPdfPageCount,
  renderPdfPageToDataUrl,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice, shareFileNative } from '../services/fileStorage';
import { PasswordPromptModal } from './PasswordPromptModal';

interface PdfViewerModalProps {
  file: StoredFile;
  onClose: () => void;
  onEditFile?: (file: StoredFile, password?: string) => void;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  file,
  onClose,
  onEditFile,
  onNotify,
}) => {
  const [password, setPassword] = useState<string | undefined>(undefined);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | undefined>(undefined);
  const [pageCount, setPageCount] = useState(file.pageCount || 1);
  const [currentPage, setCurrentPage] = useState(0);
  const [scale, setScale] = useState(1.3);
  const [pageUrl, setPageUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const info = await getPdfPageCount(file.data, password);
        if (cancelled) return;
        setPageCount(info.pageCount);
        setNeedsPassword(false);
        setPasswordError(undefined);
        const rendered = await renderPdfPageToDataUrl(file.data, currentPage, scale, password);
        if (!cancelled) {
          setPageUrl(rendered.dataUrl);
          setLoading(false);
        }
      } catch (err) {
        if (cancelled) return;
        if (err instanceof PasswordRequiredError) {
          setNeedsPassword(true);
          setPasswordError(undefined);
          setLoading(false);
        } else if (err instanceof IncorrectPasswordError) {
          setNeedsPassword(true);
          setPasswordError('Incorrect password. Please try again.');
          setLoading(false);
        } else {
          setLoading(false);
          onNotify('error', 'Failed to open PDF', (err as Error).message);
        }
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [file, currentPage, scale, password, onNotify]);

  const handleSave = async () => {
    const res = await saveBytesToDevice(file.data, file.name, file.mimeType);
    if (res !== 'cancelled') {
      onNotify('success', 'Saved to device', file.name);
    }
  };

  const handleShare = async () => {
    const res = await shareFileNative(file.data, file.name, file.mimeType);
    if (res === 'fallback-downloaded') {
      onNotify('info', 'File prepared for sharing', `${file.name} downloaded`);
    }
  };

  if (needsPassword) {
    return (
      <PasswordPromptModal
        fileName={file.name}
        errorMessage={passwordError}
        onSubmit={(pw) => setPassword(pw)}
        onCancel={onClose}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/90 backdrop-blur-sm">
      <header className="flex items-center justify-between gap-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close viewer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white truncate">
              {file.name}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
              Page {currentPage + 1} of {pageCount} · {formatBytes(file.size)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {onEditFile && (
            <button
              type="button"
              onClick={() => onEditFile(file, password)}
              className="min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700"
            >
              <Edit3 className="w-4 h-4" />
              <span className="hidden sm:inline">Edit</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleShare}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Save to device"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-auto flex items-center justify-center p-4">
        {loading ? (
          <div className="flex flex-col items-center gap-3 text-white">
            <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
            <p className="text-sm font-medium">Rendering page...</p>
          </div>
        ) : pageUrl ? (
          <img
            src={pageUrl}
            alt={`Page ${currentPage + 1}`}
            className="max-w-full rounded-lg shadow-2xl bg-white"
          />
        ) : null}
      </div>

      <footer className="flex items-center justify-between gap-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-4 py-2.5 pb-safe">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setScale((s) => Math.max(0.6, +(s - 0.25).toFixed(2)))}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
            aria-label="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono-nums font-medium text-slate-600 dark:text-slate-300 w-12 text-center">
            {Math.round((scale / 1.3) * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setScale((s) => Math.min(2.6, +(s + 0.25).toFixed(2)))}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
            aria-label="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentPage <= 0}
            onClick={() => setCurrentPage((p) => Math.max(0, p - 1))}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-40"
            aria-label="Previous page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono-nums font-semibold text-slate-800 dark:text-slate-200 px-2">
            {currentPage + 1} / {pageCount}
          </span>
          <button
            type="button"
            disabled={currentPage >= pageCount - 1}
            onClick={() => setCurrentPage((p) => Math.min(pageCount - 1, p + 1))}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 disabled:opacity-40"
            aria-label="Next page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </footer>
    </div>
  );
};
