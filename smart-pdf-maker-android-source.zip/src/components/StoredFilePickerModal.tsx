import React from 'react';
import { FileText, FolderOpen, Lock, X } from 'lucide-react';
import { StoredFile } from '../types';
import { formatBytes, formatRelativeDate } from '../services/fileStorage';

interface StoredFilePickerModalProps {
  files: StoredFile[];
  onSelect: (file: StoredFile) => void;
  onClose: () => void;
  title?: string;
}

export const StoredFilePickerModal: React.FC<StoredFilePickerModalProps> = ({
  files,
  onSelect,
  onClose,
  title = 'Choose from My Files',
}) => {
  const pdfFiles = files.filter((f) => f.mimeType === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf'));

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm sm:p-4">
      <div className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[82vh] flex flex-col">
        <div className="w-10 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mt-3 sm:hidden" />
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <FolderOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">{title}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {pdfFiles.length === 0 ? (
            <div className="py-10 text-center">
              <FileText className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="mt-2 text-sm font-medium text-slate-600 dark:text-slate-300">
                No saved PDF documents yet
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Upload a PDF from your device or create one first.
              </p>
            </div>
          ) : (
            pdfFiles.map((file) => (
              <button
                key={file.id}
                type="button"
                onClick={() => onSelect(file)}
                className="w-full min-h-[60px] flex items-center gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 p-3 text-left hover:border-blue-500 dark:hover:border-blue-500 transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/70 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                  {file.isEncrypted ? <Lock className="w-4 h-4" /> : <FileText className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {file.name}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                    {formatBytes(file.size)} · {file.pageCount} {file.pageCount === 1 ? 'page' : 'pages'} · {formatRelativeDate(file.lastOpenedAt)}
                  </p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
