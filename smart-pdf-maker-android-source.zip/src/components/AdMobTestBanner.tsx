import React from 'react';
import { ExternalLink, Settings2, X } from 'lucide-react';
import { ResolvedAdMobConfig, isNativeAndroidOrIOS } from '../services/admobService';

interface AdMobTestBannerProps {
  visible: boolean;
  config: ResolvedAdMobConfig;
  onDismiss?: () => void;
  onOpenInterstitial?: () => void;
  onConfigure?: () => void;
}

export const AdMobTestBanner: React.FC<AdMobTestBannerProps> = ({
  visible,
  config,
  onDismiss,
  onOpenInterstitial,
  onConfigure,
}) => {
  if (!visible || isNativeAndroidOrIOS()) return null;

  const isProd = !config.isTesting;

  return (
    <div className="max-w-6xl mx-auto px-4 mt-4">
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <span
            className={`px-2 py-0.5 rounded-md text-[11px] font-bold shrink-0 ${
              isProd
                ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300'
                : 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300'
            }`}
          >
            {isProd ? 'AdMob Live' : 'Test Ad'}
          </span>
          <div className="min-w-0">
            <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
              {isProd
                ? 'Google AdMob Adaptive Banner (Production)'
                : 'Google AdMob Adaptive Banner (Add your real Unit ID in Settings)'}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono-nums truncate">
              Unit ID: {config.bannerId}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {!isProd && onConfigure && (
            <button
              type="button"
              onClick={onConfigure}
              className="min-h-[34px] px-3 flex items-center gap-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Set IDs</span>
            </button>
          )}
          {onOpenInterstitial && (
            <button
              type="button"
              onClick={onOpenInterstitial}
              className="min-h-[34px] px-3 flex items-center gap-1 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700"
            >
              <span>Preview</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
          {onDismiss && (
            <button
              type="button"
              onClick={onDismiss}
              className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Hide ad banner"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
