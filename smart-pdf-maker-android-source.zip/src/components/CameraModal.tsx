import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, Upload, X } from 'lucide-react';
import { readFileAsDataUrl } from '../services/pdfEngine';

interface CameraModalProps {
  onCapture: (dataUrl: string, fileName: string) => void;
  onClose: () => void;
  title?: string;
}

export const CameraModal: React.FC<CameraModalProps> = ({
  onCapture,
  onClose,
  title = 'Camera Capture',
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [error, setError] = useState<string>('');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    async function startCamera() {
      setError('');
      setReady(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setError('Camera API is unavailable on this browser. Please upload an image instead.');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: facingMode }, width: { ideal: 1920 }, height: { ideal: 1080 } },
          audio: false,
        });
        if (!active) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setReady(true);
        }
      } catch (err) {
        setError(
          'Camera permission denied or no camera detected. You can upload a photo directly below.'
        );
      }
    }
    startCamera();
    return () => {
      active = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, [facingMode]);

  const handleCapture = () => {
    const video = videoRef.current;
    if (!video || !ready) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    onCapture(dataUrl, `scan_${Date.now()}.jpg`);
  };

  const handleFallbackFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await readFileAsDataUrl(file);
    onCapture(dataUrl, file.name);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-white">
      <header className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
        <button
          type="button"
          onClick={onClose}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-slate-800"
          aria-label="Close camera"
        >
          <X className="w-5 h-5" />
        </button>
        <h3 className="text-base font-semibold">{title}</h3>
        <button
          type="button"
          onClick={() => setFacingMode((m) => (m === 'environment' ? 'user' : 'environment'))}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-slate-800"
          aria-label="Switch camera"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </header>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-black p-4">
        {error ? (
          <div className="max-w-sm text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto text-blue-400">
              <Camera className="w-7 h-7" />
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">{error}</p>
            <label className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
              <Upload className="w-4 h-4" />
              <span>Choose Photo from Device</span>
              <input type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFallbackFile} />
            </label>
          </div>
        ) : (
          <video
            ref={videoRef}
            playsInline
            muted
            className="max-h-full max-w-full rounded-xl object-contain"
          />
        )}
      </div>

      {!error && (
        <footer className="flex items-center justify-center gap-6 px-4 py-5 border-t border-slate-800 pb-safe">
          <label className="min-h-[44px] px-4 flex items-center gap-2 rounded-xl bg-slate-800 text-xs font-semibold cursor-pointer hover:bg-slate-700">
            <Upload className="w-4 h-4" />
            <span>Gallery</span>
            <input type="file" accept="image/*" className="hidden" onChange={handleFallbackFile} />
          </label>
          <button
            type="button"
            onClick={handleCapture}
            disabled={!ready}
            className="w-16 h-16 rounded-full bg-white p-1.5 disabled:opacity-40 active:scale-95 transition-transform"
            aria-label="Capture photo"
          >
            <span className="block w-full h-full rounded-full border-4 border-blue-600 bg-white" />
          </button>
          <div className="w-20" />
        </footer>
      )}
    </div>
  );
};
