import React, { useEffect, useState } from 'react';
import { CheckCircle2, Smartphone, X } from 'lucide-react';
import { ResolvedAdMobConfig } from '../services/admobService';

interface AdMobTestInterstitialProps {
  kind: 'interstitial' | 'rewarded';
  config: ResolvedAdMobConfig;
  onClose: (rewardGranted?: boolean) => void;
}

export const AdMobTestInterstitial: React.FC<AdMobTestInterstitialProps> = ({
  kind,
  config,
  onClose,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(kind === 'rewarded' ? 5 : 2);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const timer = setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [secondsLeft]);

  const canClose = secondsLeft <= 0;
  const isProd = !config.isTesting;
  const activeUnitId = kind === 'rewarded' ? config.rewardedId : config.interstitialId;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl">
        <div className="px-5 py-3.5 bg-slate-100 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className={`px-2 py-0.5 rounded-md text-xs font-bold ${
                isProd
                  ? 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300'
                  : 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300'
              }`}
            >
              {isProd ? 'Production Ad' : 'Test Ad'}
            </span>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 capitalize">
              AdMob {kind}
            </span>
          </div>

          {canClose ? (
            <button
              type="button"
              onClick={() => onClose(kind === 'rewarded')}
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-700"
              aria-label="Close ad"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <span className="text-xs font-mono-nums font-semibold text-slate-500">
              {secondsLeft}s
            </span>
          )}
        </div>

        <div className="p-6 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto">
            <Smartphone className="w-8 h-8" />
          </div>
          <div className="space-y-1.5">
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Google AdMob {kind === 'rewarded' ? 'Rewarded Video' : 'Interstitial'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {isProd
                ? 'Configured with your Production Ad Unit ID. When running inside the compiled Android APK, the Google Mobile Ads SDK displays live ads using this unit.'
                : 'Running with Google Test Ad Unit ID. Enter your real AdMob IDs in Settings or .env to serve live production ads in your Android APK.'}
            </p>
          </div>

          <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 text-left space-y-1">
            <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Active Ad Unit ID ({isProd ? 'Production' : 'Test'})
            </p>
            <p className="text-xs font-mono-nums font-bold text-slate-900 dark:text-white break-all">
              {activeUnitId}
            </p>
          </div>

          <button
            type="button"
            disabled={!canClose}
            onClick={() => onClose(kind === 'rewarded')}
            className="w-full min-h-[46px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
          >
            {canClose && <CheckCircle2 className="w-4 h-4" />}
            <span>
              {canClose
                ? kind === 'rewarded'
                  ? 'Collect Reward & Close'
                  : 'Close Ad'
                : `Wait ${secondsLeft}s...`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
