import React, { useCallback, useEffect, useState } from 'react';
import {
  FolderOpen,
  Grid2x2,
  Home,
  ScanLine,
  Settings as SettingsIcon,
} from 'lucide-react';
import { AppSettings, NavTab, StoredFile, ToastMessage, ToolId } from './types';
import { TRANSLATIONS } from './i18n/translations';
import {
  clearAllStoredFiles,
  deleteStoredFile,
  getAllStoredFiles,
  loadSettings,
  renameStoredFile,
  saveFileToLocalStore,
  saveSettings,
  touchStoredFile,
} from './services/fileStorage';
import {
  PasswordRequiredError,
  getPdfPageCount,
} from './services/pdfEngine';
import {
  hideNativeBanner,
  initAdMob,
  resolveAdMobConfig,
  showNativeBanner,
  triggerInterstitialAd,
  triggerRewardedAd,
} from './services/admobService';
import { ToastBanner } from './components/ToastBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PdfViewerModal } from './components/PdfViewerModal';
import { AdMobTestBanner } from './components/AdMobTestBanner';
import { AdMobTestInterstitial } from './components/AdMobTestInterstitial';
import { HomeView } from './views/HomeView';
import { ToolsView } from './views/ToolsView';
import { MyFilesView } from './views/MyFilesView';
import { SettingsView } from './views/SettingsView';
import { ImageToPdfTool } from './tools/ImageToPdfTool';
import { ScannerTool } from './tools/ScannerTool';
import { PdfEditorTool } from './tools/PdfEditorTool';
import { CompressorTool } from './tools/CompressorTool';
import { MergeSplitTool } from './tools/MergeSplitTool';
import { ConverterTool } from './tools/ConverterTool';
import { SecurityTool } from './tools/SecurityTool';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [activeTool, setActiveTool] = useState<ToolId | null>(null);
  const [editorPreload, setEditorPreload] = useState<{
    file: StoredFile;
    password?: string;
  } | null>(null);

  const [files, setFiles] = useState<StoredFile[]>([]);
  const [viewerFile, setViewerFile] = useState<StoredFile | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [testAdModal, setTestAdModal] = useState<'interstitial' | 'rewarded' | null>(null);
  const [createdCount, setCreatedCount] = useState(0);

  const t = TRANSLATIONS[settings.language] || TRANSLATIONS.en;

  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
  }, [settings.theme, settings.language]);

  const adMobConfig = resolveAdMobConfig(settings);

  useEffect(() => {
    if (settings.admobEnabled) {
      initAdMob(adMobConfig.isTesting).then(() => showNativeBanner(adMobConfig));
    } else {
      hideNativeBanner();
    }
  }, [
    settings.admobEnabled,
    adMobConfig.isTesting,
    adMobConfig.bannerId,
  ]);

  const refreshFiles = useCallback(async () => {
    try {
      const list = await getAllStoredFiles();
      setFiles(list);
    } catch {
      // ignore IndexedDB unavailable
    }
  }, []);

  useEffect(() => {
    refreshFiles();
  }, [refreshFiles]);

  const notify = useCallback(
    (type: ToastMessage['type'], title: string, description?: string) => {
      const id = `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      setToasts((prev) => [...prev.slice(-2), { id, type, title, description }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((item) => item.id !== id));
      }, 4500);
    },
    []
  );

  const handleUpdateSettings = (patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  };

  const handleSaveFile = async (
    fileInput: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>
  ): Promise<StoredFile> => {
    const saved = await saveFileToLocalStore(fileInput);
    await refreshFiles();
    if (fileInput.category === 'created' && settings.admobEnabled) {
      const nextCount = createdCount + 1;
      setCreatedCount(nextCount);
      if (nextCount % 2 === 0) {
        triggerInterstitialAd(adMobConfig, () => setTestAdModal('interstitial'));
      }
    }
    return saved;
  };

  const handleOpenViewer = async (file: StoredFile) => {
    await touchStoredFile(file.id);
    await refreshFiles();
    setViewerFile(file);
  };

  const handleImportFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []);
    if (!selected.length) return;
    for (const f of selected) {
      try {
        const bytes = new Uint8Array(await f.arrayBuffer());
        let pageCount = 1;
        let isEncrypted = false;
        try {
          const info = await getPdfPageCount(bytes);
          pageCount = info.pageCount;
          isEncrypted = info.isEncrypted;
        } catch (err) {
          if (err instanceof PasswordRequiredError) {
            isEncrypted = true;
          }
        }
        const saved = await handleSaveFile({
          name: f.name,
          size: bytes.byteLength,
          pageCount,
          category: 'downloaded',
          mimeType: f.type || 'application/pdf',
          data: bytes,
          isEncrypted,
        });
        notify('success', 'Imported to My Files', saved.name);
      } catch (err) {
        notify('error', 'Failed to import file', (err as Error).message);
      }
    }
    e.target.value = '';
  };

  const openTool = (tool: ToolId) => {
    setEditorPreload(null);
    setActiveTool(tool);
  };

  const renderToolScreen = () => {
    if (!activeTool) return null;

    if (activeTool === 'image-to-pdf') {
      return (
        <ImageToPdfTool
          title={t.toolImageToPdf}
          settings={settings}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'jpg-to-pdf') {
      return (
        <ImageToPdfTool
          title={t.toolJpgToPdf}
          acceptMime="image/jpeg,image/jpg,.jpg,.jpeg"
          settings={settings}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'png-to-pdf') {
      return (
        <ImageToPdfTool
          title={t.toolPngToPdf}
          acceptMime="image/png,.png"
          settings={settings}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'scanner') {
      return (
        <ScannerTool
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'editor' || activeTool === 'signature') {
      return (
        <PdfEditorTool
          initialMode={activeTool === 'signature' ? 'signature' : 'select'}
          initialFile={editorPreload}
          storedFiles={files}
          onBack={() => {
            setActiveTool(null);
            setEditorPreload(null);
          }}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'compressor') {
      return (
        <CompressorTool
          settings={settings}
          storedFiles={files}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'merge' || activeTool === 'split') {
      return (
        <MergeSplitTool
          initialTab={activeTool}
          storedFiles={files}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (
      activeTool === 'pdf-to-image' ||
      activeTool === 'word-to-pdf' ||
      activeTool === 'excel-to-pdf' ||
      activeTool === 'ppt-to-pdf' ||
      activeTool === 'pdf-to-word'
    ) {
      return (
        <ConverterTool
          mode={activeTool}
          settings={settings}
          storedFiles={files}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    if (activeTool === 'password') {
      return (
        <SecurityTool
          storedFiles={files}
          onBack={() => setActiveTool(null)}
          onSaveFile={handleSaveFile}
          onNotify={notify}
          onOpenViewer={handleOpenViewer}
        />
      );
    }
    return null;
  };

  const navItems: Array<{ id: NavTab; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'home', label: t.navHome, icon: Home },
    { id: 'tools', label: t.navTools, icon: Grid2x2 },
    { id: 'files', label: t.navFiles, icon: FolderOpen },
    { id: 'settings', label: t.navSettings, icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <OfflineIndicator />
      <ToastBanner
        toasts={toasts}
        onDismiss={(id) => setToasts((prev) => prev.filter((item) => item.id !== id))}
      />

      {activeTool ? (
        renderToolScreen()
      ) : (
        <>
          {/* Three-Zone Top App Bar */}
          <header className="sticky top-0 z-30 h-14 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 pt-safe">
            <div className="max-w-6xl mx-auto px-4 h-full flex items-center justify-between gap-8">
              <button
                type="button"
                onClick={() => setActiveTab('home')}
                className="text-base sm:text-lg font-extrabold tracking-tight text-blue-600 dark:text-blue-400 whitespace-nowrap shrink-0"
              >
                Smart PDF Maker
              </button>

              <nav className="hidden md:flex items-center gap-6 text-sm font-semibold">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                      activeTab === item.id
                        ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </nav>

              <div className="shrink-0">
                <button
                  type="button"
                  onClick={() => openTool('scanner')}
                  className="min-h-[38px] px-3.5 flex items-center gap-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0"
                >
                  <ScanLine className="w-3.5 h-3.5" />
                  <span>Scan PDF</span>
                </button>
              </div>
            </div>
          </header>

          {/* Main Scrollable Content */}
          <main className="pb-24 md:pb-10">
            {activeTab === 'home' && (
              <HomeView
                t={t}
                recentFiles={files}
                onOpenTool={openTool}
                onGoToAllTools={() => setActiveTab('tools')}
                onOpenFile={handleOpenViewer}
                onImportPdf={handleImportFiles}
              />
            )}
            {activeTab === 'tools' && (
              <ToolsView t={t} onOpenTool={openTool} />
            )}
            {activeTab === 'files' && (
              <MyFilesView
                t={t}
                files={files}
                onOpenFile={handleOpenViewer}
                onEditFile={(file) => {
                  setEditorPreload({ file });
                  setActiveTool('editor');
                }}
                onRenameFile={async (id, newName) => {
                  await renameStoredFile(id, newName);
                  await refreshFiles();
                  notify('success', 'File renamed', newName);
                }}
                onDeleteFile={async (id) => {
                  await deleteStoredFile(id);
                  await refreshFiles();
                  notify('info', 'File deleted');
                }}
                onImportFiles={handleImportFiles}
                onNotify={notify}
              />
            )}
            {activeTab === 'settings' && (
              <SettingsView
                t={t}
                settings={settings}
                files={files}
                onUpdateSettings={handleUpdateSettings}
                onClearStorage={async () => {
                  await clearAllStoredFiles();
                  await refreshFiles();
                }}
                onNotify={notify}
                onTriggerTestInterstitial={() =>
                  triggerInterstitialAd(adMobConfig, () => setTestAdModal('interstitial'))
                }
                onTriggerTestRewarded={() =>
                  triggerRewardedAd(
                    adMobConfig,
                    () => setTestAdModal('rewarded'),
                    () => notify('success', 'Reward Earned')
                  )
                }
              />
            )}

            <AdMobTestBanner
              visible={settings.admobEnabled}
              config={adMobConfig}
              onDismiss={() => handleUpdateSettings({ admobEnabled: false })}
              onConfigure={() => setActiveTab('settings')}
              onOpenInterstitial={() =>
                triggerInterstitialAd(adMobConfig, () => setTestAdModal('interstitial'))
              }
            />
          </main>

          {/* Fixed Bottom Navigation (Mobile Thumb Zone) */}
          <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe">
            <div className="grid grid-cols-4 h-[60px] items-center">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveTab(item.id)}
                    className={`min-h-[44px] flex flex-col items-center justify-center transition-colors ${
                      active
                        ? 'text-blue-600 dark:text-blue-400'
                        : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="mt-1 text-[10px] font-semibold tracking-tight whitespace-nowrap">
                      {item.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </nav>
        </>
      )}

      {viewerFile && (
        <PdfViewerModal
          file={viewerFile}
          onClose={() => setViewerFile(null)}
          onEditFile={(file, pw) => {
            setViewerFile(null);
            setEditorPreload({ file, password: pw });
            setActiveTool('editor');
          }}
          onNotify={notify}
        />
      )}

      {testAdModal && (
        <AdMobTestInterstitial
          kind={testAdModal}
          config={adMobConfig}
          onClose={(rewardGranted) => {
            setTestAdModal(null);
            if (rewardGranted) {
              notify('success', 'Reward Collected', 'AdMob Rewarded Ad completed.');
            }
          }}
        />
      )}
    </div>
  );
}
