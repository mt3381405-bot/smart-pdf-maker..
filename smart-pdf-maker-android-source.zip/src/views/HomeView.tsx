import React from 'react';
import {
  ChevronRight,
  FileArchive,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  Grid2x2,
  Image as ImageIcon,
  ImagePlus,
  Lock,
  Merge,
  PenTool,
  Presentation,
  ScanLine,
  Scissors,
  Sliders,
  Upload,
} from 'lucide-react';
import { StoredFile, ToolId } from '../types';
import { TranslationStrings } from '../i18n/translations';
import { formatBytes, formatRelativeDate } from '../services/fileStorage';

interface HomeViewProps {
  t: TranslationStrings;
  recentFiles: StoredFile[];
  onOpenTool: (tool: ToolId) => void;
  onGoToAllTools: () => void;
  onOpenFile: (file: StoredFile) => void;
  onImportPdf: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  t,
  recentFiles,
  onOpenTool,
  onGoToAllTools,
  onOpenFile,
  onImportPdf,
}) => {
  const mainButtons: Array<{
    id: ToolId | 'all-tools';
    label: string;
    hint: string;
    icon: React.FC<{ className?: string }>;
    accent?: boolean;
  }> = [
    { id: 'image-to-pdf', label: t.toolImageToPdf, hint: 'Photos & gallery', icon: ImagePlus, accent: true },
    { id: 'scanner', label: t.toolScanner, hint: 'Auto edge & warp', icon: ScanLine, accent: true },
    { id: 'editor', label: t.toolEditor, hint: 'Text, draw & pages', icon: Sliders },
    { id: 'compressor', label: t.toolCompressor, hint: 'Reduce file size', icon: FileArchive },
    { id: 'merge', label: t.toolMerge, hint: 'Combine PDFs', icon: Merge },
    { id: 'split', label: t.toolSplit, hint: 'Extract ranges', icon: Scissors },
    { id: 'pdf-to-image', label: t.toolPdfToImage, hint: 'Export JPG / PNG', icon: ImageIcon },
    { id: 'word-to-pdf', label: t.toolWordToPdf, hint: '.docx to PDF', icon: FileText },
    { id: 'excel-to-pdf', label: t.toolExcelToPdf, hint: '.xlsx / .csv', icon: FileSpreadsheet },
    { id: 'ppt-to-pdf', label: t.toolPptToPdf, hint: '.pptx slides', icon: Presentation },
    { id: 'signature', label: t.toolSignature, hint: 'Sign documents', icon: PenTool },
    { id: 'password', label: t.toolPassword, hint: 'Lock & unlock', icon: Lock },
    { id: 'all-tools', label: t.toolAllTools, hint: 'Browse full suite', icon: Grid2x2 },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-8">
      {/* Primary Hero Action Strip */}
      <section className="rounded-3xl bg-gradient-to-br from-blue-600 to-blue-700 dark:from-blue-700 dark:to-blue-900 p-6 sm:p-7 text-white shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5 max-w-xl">
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-balance">
              {t.appName}
            </h1>
            <p className="text-sm text-blue-100 leading-relaxed">
              {t.tagline}. Scan, convert, edit, compress, sign, and protect PDFs with zero cloud uploads.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onOpenTool('scanner')}
              className="min-h-[46px] px-5 flex items-center gap-2 rounded-xl bg-white text-blue-700 text-sm font-bold hover:bg-blue-50 active:scale-[0.98] transition-all"
            >
              <ScanLine className="w-4 h-4" />
              <span>{t.toolScanner}</span>
            </button>
            <label className="min-h-[46px] px-4 flex items-center gap-2 rounded-xl bg-blue-500/30 border border-white/25 text-white text-sm font-semibold cursor-pointer hover:bg-blue-500/45 transition-colors">
              <Upload className="w-4 h-4" />
              <span>Import PDF</span>
              <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={onImportPdf} />
            </label>
          </div>
        </div>
      </section>

      {/* Main 13 Tool Buttons */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t.quickActions}
          </h2>
          <button
            type="button"
            onClick={onGoToAllTools}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <span>{t.allTools}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {mainButtons.map((btn) => {
            const Icon = btn.icon;
            return (
              <button
                key={btn.id}
                type="button"
                onClick={() =>
                  btn.id === 'all-tools' ? onGoToAllTools() : onOpenTool(btn.id)
                }
                className="group min-h-[84px] rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 p-4 text-left hover:border-blue-500 dark:hover:border-blue-500 active:scale-[0.98] transition-all flex items-start gap-3.5"
              >
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                    btn.accent
                      ? 'bg-blue-600 text-white'
                      : 'bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                    {btn.label}
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 truncate">
                    {btn.hint}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Recent Files */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t.recentFiles}
          </h2>
        </div>

        {recentFiles.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 p-8 text-center">
            <FolderOpen className="w-9 h-9 text-slate-300 dark:text-slate-600 mx-auto" />
            <p className="mt-2.5 text-sm text-slate-600 dark:text-slate-400">
              {t.noRecentFiles}
            </p>
          </div>
        ) : (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
            {recentFiles.slice(0, 5).map((file) => (
              <button
                key={file.id}
                type="button"
                onClick={() => onOpenFile(file)}
                className="w-full min-h-[64px] px-4 py-3 flex items-center justify-between gap-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 first:rounded-t-2xl last:rounded-b-2xl transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {file.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                      {formatBytes(file.size)} · {file.pageCount} {file.pageCount === 1 ? 'page' : 'pages'} · {formatRelativeDate(file.lastOpenedAt)}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
