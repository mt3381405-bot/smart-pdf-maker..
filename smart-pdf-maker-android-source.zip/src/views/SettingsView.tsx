import React, { useState } from 'react';
import {
  ChevronRight,
  Download,
  Globe,
  HardDrive,
  Info,
  Mail,
  Moon,
  Shield,
  Smartphone,
  Sun,
  Trash2,
  X,
} from 'lucide-react';
import { LanguageCode, PageSizePreset, StoredFile, AppSettings } from '../types';
import { LANGUAGE_NAMES, TranslationStrings } from '../i18n/translations';
import { formatBytes } from '../services/fileStorage';
import {
  ADMOB_TEST_IDS,
  isTestAdMobId,
  isValidAdMobAppId,
  isValidAdMobUnitId,
  resolveAdMobConfig,
} from '../services/admobService';
import { PWAInstallButton } from '../components/PWAInstallButton';

interface SettingsViewProps {
  t: TranslationStrings;
  settings: AppSettings;
  files: StoredFile[];
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onClearStorage: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onTriggerTestInterstitial: () => void;
  onTriggerTestRewarded: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  t,
  settings,
  files,
  onUpdateSettings,
  onClearStorage,
  onNotify,
  onTriggerTestInterstitial,
  onTriggerTestRewarded,
}) => {
  const [modal, setModal] = useState<'privacy' | 'about' | 'support' | 'apk' | null>(null);
  const [supportSubject, setSupportSubject] = useState('');
  const [supportMsg, setSupportMsg] = useState('');
  const [appIdDraft, setAppIdDraft] = useState(settings.admobAppId);
  const [bannerIdDraft, setBannerIdDraft] = useState(settings.admobBannerId);
  const [interstitialIdDraft, setInterstitialIdDraft] = useState(settings.admobInterstitialId);
  const [rewardedIdDraft, setRewardedIdDraft] = useState(settings.admobRewardedId);

  const resolvedAdMob = resolveAdMobConfig(settings);
  const totalUsed = files.reduce((sum, f) => sum + f.size, 0);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
          {t.settingsTitle}
        </h1>
        <PWAInstallButton />
      </div>

      {/* Appearance */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.appearance}</h2>
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
          <button
            type="button"
            onClick={() => onUpdateSettings({ theme: 'light' })}
            className={`min-h-[42px] flex items-center justify-center gap-2 rounded-lg text-xs font-bold transition-colors ${
              settings.theme === 'light'
                ? 'bg-white text-blue-600 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Sun className="w-4 h-4" />
            <span>{t.lightMode}</span>
          </button>
          <button
            type="button"
            onClick={() => onUpdateSettings({ theme: 'dark' })}
            className={`min-h-[42px] flex items-center justify-center gap-2 rounded-lg text-xs font-bold transition-colors ${
              settings.theme === 'dark'
                ? 'bg-slate-800 text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Moon className="w-4 h-4" />
            <span>{t.darkMode}</span>
          </button>
        </div>
      </section>

      {/* Preferences */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
        <div className="p-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-white">{t.languageLabel}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Interface display language</p>
            </div>
          </div>
          <select
            value={settings.language}
            onChange={(e) => onUpdateSettings({ language: e.target.value as LanguageCode })}
            className="min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-semibold text-slate-800 dark:text-slate-100"
          >
            {(Object.keys(LANGUAGE_NAMES) as LanguageCode[]).map((code) => (
              <option key={code} value={code}>
                {LANGUAGE_NAMES[code]}
              </option>
            ))}
          </select>
        </div>

        <div className="p-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white">{t.defaultPageSize}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Used for Image to PDF and converters</p>
          </div>
          <select
            value={settings.defaultPageSize}
            onChange={(e) => onUpdateSettings({ defaultPageSize: e.target.value as PageSizePreset })}
            className="min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-semibold text-slate-800 dark:text-slate-100"
          >
            {(['A4', 'A3', 'Letter'] as PageSizePreset[]).map((sz) => (
              <option key={sz} value={sz}>
                {sz}
              </option>
            ))}
          </select>
        </div>
      </section>

      {/* Google AdMob Configuration (Production & Test) */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              Google AdMob Ads
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {resolvedAdMob.isTesting
                ? 'Currently using Google Test IDs'
                : 'Production mode active with your live Ad Unit IDs'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onUpdateSettings({ admobEnabled: !settings.admobEnabled })}
            className={`min-h-[36px] px-3.5 rounded-xl text-xs font-bold transition-colors ${
              settings.admobEnabled
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {settings.admobEnabled ? 'Enabled' : 'Disabled'}
          </button>
        </div>

        {/* Mode Toggle */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
          <button
            type="button"
            onClick={() => onUpdateSettings({ admobMode: 'production' })}
            className={`min-h-[38px] rounded-lg text-xs font-bold transition-colors ${
              settings.admobMode === 'production'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Production (Live Ads)
          </button>
          <button
            type="button"
            onClick={() => onUpdateSettings({ admobMode: 'test' })}
            className={`min-h-[38px] rounded-lg text-xs font-bold transition-colors ${
              settings.admobMode === 'test'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Test Mode
          </button>
        </div>

        {/* Real Production IDs Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const cleanApp = appIdDraft.trim();
            const cleanBanner = bannerIdDraft.trim();
            const cleanInter = interstitialIdDraft.trim();
            const cleanReward = rewardedIdDraft.trim();

            if (cleanApp && !isValidAdMobAppId(cleanApp)) {
              onNotify('error', 'Invalid AdMob App ID', 'Format: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY');
              return;
            }
            for (const [label, val] of [
              ['Banner Unit ID', cleanBanner],
              ['Interstitial Unit ID', cleanInter],
              ['Rewarded Unit ID', cleanReward],
            ] as const) {
              if (val && !isValidAdMobUnitId(val)) {
                onNotify('error', `Invalid ${label}`, 'Format: ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY');
                return;
              }
            }
            if (
              settings.admobMode === 'production' &&
              (isTestAdMobId(cleanBanner) || isTestAdMobId(cleanInter) || isTestAdMobId(cleanReward))
            ) {
              onNotify('info', 'Google Test ID detected', 'Replace with your AdMob Console unit IDs for live revenue.');
            }
            onUpdateSettings({
              admobAppId: cleanApp,
              admobBannerId: cleanBanner,
              admobInterstitialId: cleanInter,
              admobRewardedId: cleanReward,
            });
            onNotify('success', 'AdMob IDs saved');
          }}
          className="space-y-3"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Android App ID (ca-app-pub-...~...)
              </label>
              <input
                type="text"
                value={appIdDraft}
                onChange={(e) => setAppIdDraft(e.target.value)}
                placeholder="ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy"
                className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-mono-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Banner Ad Unit ID (ca-app-pub-.../...)
              </label>
              <input
                type="text"
                value={bannerIdDraft}
                onChange={(e) => setBannerIdDraft(e.target.value)}
                placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"
                className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-mono-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Interstitial Ad Unit ID
              </label>
              <input
                type="text"
                value={interstitialIdDraft}
                onChange={(e) => setInterstitialIdDraft(e.target.value)}
                placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"
                className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-mono-nums"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                Rewarded Ad Unit ID
              </label>
              <input
                type="text"
                value={rewardedIdDraft}
                onChange={(e) => setRewardedIdDraft(e.target.value)}
                placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"
                className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs font-mono-nums"
              />
            </div>
          </div>

          <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 space-y-1 text-[11px] font-mono-nums text-slate-500 dark:text-slate-400">
            <p className="truncate">Active Mode: {resolvedAdMob.isTesting ? 'Test Mode' : 'Production (Live)'}</p>
            <p className="truncate">Active Banner: {resolvedAdMob.bannerId}</p>
            <p className="truncate">Active Interstitial: {resolvedAdMob.interstitialId}</p>
            <p className="truncate">Fallback Test App ID: {ADMOB_TEST_IDS.appId}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              type="submit"
              className="min-h-[42px] rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700"
            >
              Save AdMob IDs
            </button>
            <button
              type="button"
              onClick={onTriggerTestInterstitial}
              className="min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              Preview Interstitial
            </button>
            <button
              type="button"
              onClick={onTriggerTestRewarded}
              className="min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              Preview Rewarded
            </button>
          </div>
        </form>
      </section>

      {/* Storage Settings */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <HardDrive className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">{t.storageSettings}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                {files.length} files stored locally · {formatBytes(totalUsed)} used
              </p>
            </div>
          </div>
          <button
            type="button"
            disabled={files.length === 0}
            onClick={async () => {
              await onClearStorage();
              onNotify('success', 'Local file library cleared');
            }}
            className="min-h-[38px] px-3 flex items-center gap-1.5 rounded-xl border border-rose-200 dark:border-rose-900 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 disabled:opacity-40"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Storage</span>
          </button>
        </div>
      </section>

      {/* Info & Support */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
        <a
          href="/smart-pdf-maker-android-source.zip"
          download="smart-pdf-maker-android-source.zip"
          onClick={() => onNotify('success', 'Downloading Project ZIP', 'Includes full Android Gradle project & GitHub Actions workflow')}
          className="w-full min-h-[56px] px-4 flex items-center justify-between gap-3 text-left hover:bg-blue-50/70 dark:hover:bg-blue-950/30 rounded-t-2xl transition-colors"
        >
          <div className="flex items-center gap-3">
            <Download className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <div>
              <span className="text-sm font-bold text-blue-600 dark:text-blue-400 block">
                Download Complete Project ZIP
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Full Android Gradle source, MainActivity, Manifest & GitHub APK workflow
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-blue-500 shrink-0" />
        </a>
        {[
          { id: 'apk' as const, label: 'Android APK Build Instructions', icon: Smartphone },
          { id: 'privacy' as const, label: t.privacyPolicy, icon: Shield },
          { id: 'about' as const, label: t.aboutApp, icon: Info },
          { id: 'support' as const, label: t.contactSupport, icon: Mail },
        ].map((row) => {
          const Icon = row.icon;
          return (
            <button
              key={row.id}
              type="button"
              onClick={() => setModal(row.id)}
              className="w-full min-h-[56px] px-4 flex items-center justify-between gap-3 text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 last:rounded-b-2xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span className="text-sm font-semibold text-slate-900 dark:text-white">{row.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          );
        })}
      </section>

      {/* Modals */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {modal === 'privacy'
                  ? t.privacyPolicy
                  : modal === 'about'
                  ? t.aboutApp
                  : modal === 'apk'
                  ? 'Android APK Build Guide'
                  : t.contactSupport}
              </h3>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {modal === 'privacy' && (
              <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                <p>
                  <strong>100% On-Device Processing:</strong> Smart PDF Maker creates, edits, scans, compresses, converts, and encrypts your documents locally inside your device browser/runtime.
                </p>
                <p>
                  <strong>Zero Unauthorized Uploads:</strong> Your private documents are never uploaded to external servers. Local files are saved in your device storage (IndexedDB and Storage Access Framework file picker).
                </p>
                <p>
                  <strong>Permissions:</strong> Camera access is requested only when you tap Camera Scanner or Capture Photo.
                </p>
              </div>
            )}

            {modal === 'about' && (
              <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                <p>
                  <strong>Smart PDF Maker</strong> is a complete mobile-first PDF creation, scanning, annotation, conversion, and security suite.
                </p>
                <p>
                  Built with local PDF processing engines (@cantoo/pdf-lib, PDF.js, Mammoth, SheetJS, JSZip, docx) and installable as an offline-capable PWA or compiled into a native Android APK via Capacitor.
                </p>
              </div>
            )}

            {modal === 'apk' && (
              <div className="space-y-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                <p>
                  The complete <code>android/</code> Gradle project (<code>build.gradle</code>, <code>settings.gradle</code>, <code>AndroidManifest.xml</code>, <code>MainActivity.java</code>) and <code>.github/workflows/build-apk.yml</code> are included in this repository.
                </p>
                <pre className="rounded-xl bg-slate-950 text-slate-100 p-3.5 text-xs overflow-x-auto font-mono">
{`npm install
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug`}
                </pre>
                <p>
                  Or push the downloaded ZIP to GitHub and run <strong>Actions → Build Android APK</strong> to generate <code>app-debug.apk</code> in the cloud.
                </p>
                <a
                  href="/smart-pdf-maker-android-source.zip"
                  download="smart-pdf-maker-android-source.zip"
                  className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-xs sm:text-sm font-semibold text-white hover:bg-blue-700"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Complete Project ZIP</span>
                </a>
              </div>
            )}

            {modal === 'support' && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onNotify('success', 'Support message prepared', 'Thank you for your feedback.');
                  setSupportSubject('');
                  setSupportMsg('');
                  setModal(null);
                }}
                className="space-y-3"
              >
                <input
                  type="text"
                  required
                  value={supportSubject}
                  onChange={(e) => setSupportSubject(e.target.value)}
                  placeholder="Subject (e.g. Compression feedback)"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm"
                />
                <textarea
                  required
                  rows={4}
                  value={supportMsg}
                  onChange={(e) => setSupportMsg(e.target.value)}
                  placeholder="Describe your question or issue..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3 text-sm"
                />
                <button
                  type="submit"
                  className="w-full min-h-[44px] rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700"
                >
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
