import React, { useState } from 'react';
import {
  FileArchive,
  FileCode2,
  FileImage,
  FileSpreadsheet,
  FileText,
  Image as ImageIcon,
  ImagePlus,
  Lock,
  Merge,
  PenTool,
  Presentation,
  ScanLine,
  Scissors,
  Search,
  Sliders,
} from 'lucide-react';
import { ToolId } from '../types';
import { TranslationStrings } from '../i18n/translations';

interface ToolsViewProps {
  t: TranslationStrings;
  onOpenTool: (tool: ToolId) => void;
}

type ToolCategory = 'all' | 'create' | 'edit' | 'organize' | 'convert' | 'security';

export const ToolsView: React.FC<ToolsViewProps> = ({ t, onOpenTool }) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<ToolCategory>('all');

  const tools: Array<{
    id: ToolId;
    title: string;
    desc: string;
    category: Exclude<ToolCategory, 'all'>;
    icon: React.FC<{ className?: string }>;
  }> = [
    { id: 'image-to-pdf', title: t.toolImageToPdf, desc: 'Combine gallery photos with crop, filters & page sizes', category: 'create', icon: ImagePlus },
    { id: 'scanner', title: t.toolScanner, desc: 'Capture documents with edge detection & perspective warp', category: 'create', icon: ScanLine },
    { id: 'jpg-to-pdf', title: t.toolJpgToPdf, desc: 'Convert JPG / JPEG images into a PDF document', category: 'convert', icon: FileImage },
    { id: 'png-to-pdf', title: t.toolPngToPdf, desc: 'Convert PNG images with custom margins & layout', category: 'convert', icon: FileImage },
    { id: 'editor', title: t.toolEditor, desc: 'Add text, highlights, drawings, images, rotate & delete pages', category: 'edit', icon: Sliders },
    { id: 'signature', title: t.toolSignature, desc: 'Draw a signature and place it onto any PDF page', category: 'edit', icon: PenTool },
    { id: 'compressor', title: t.toolCompressor, desc: 'Shrink PDF file size using Low, Medium or High levels', category: 'organize', icon: FileArchive },
    { id: 'merge', title: t.toolMerge, desc: 'Merge multiple PDFs and pick specific pages', category: 'organize', icon: Merge },
    { id: 'split', title: t.toolSplit, desc: 'Split a PDF by page range or extract individual pages', category: 'organize', icon: Scissors },
    { id: 'pdf-to-image', title: t.toolPdfToImage, desc: 'Export PDF pages to JPG or PNG images and ZIP', category: 'convert', icon: ImageIcon },
    { id: 'word-to-pdf', title: t.toolWordToPdf, desc: 'Convert .docx Word documents into PDF', category: 'convert', icon: FileText },
    { id: 'excel-to-pdf', title: t.toolExcelToPdf, desc: 'Convert .xlsx, .xls, and .csv sheets into PDF tables', category: 'convert', icon: FileSpreadsheet },
    { id: 'ppt-to-pdf', title: t.toolPptToPdf, desc: 'Convert .pptx slides into a presentation PDF', category: 'convert', icon: Presentation },
    { id: 'pdf-to-word', title: t.toolPdfToWord, desc: 'Extract text from PDF into an editable .docx file', category: 'convert', icon: FileCode2 },
    { id: 'password', title: t.toolPassword, desc: 'Lock PDFs with AES-256 encryption or open with password', category: 'security', icon: Lock },
  ];

  const filtered = tools.filter((item) => {
    const matchesCat = category === 'all' || item.category === category;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q || item.title.toLowerCase().includes(q) || item.desc.toLowerCase().includes(q);
    return matchesCat && matchesQuery;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-5">
      <div className="space-y-1">
        <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
          {t.allTools}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Every PDF converter, editor, scanner, and security utility runs directly on your device.
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t.searchTools}
          className="w-full min-h-[46px] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-10 pr-4 text-sm text-slate-900 dark:text-white focus:border-blue-600 focus:outline-none"
        />
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {(
          [
            { id: 'all', label: 'All' },
            { id: 'create', label: 'Create & Scan' },
            { id: 'edit', label: 'Edit & Sign' },
            { id: 'organize', label: 'Compress & Organize' },
            { id: 'convert', label: 'Converters' },
            { id: 'security', label: 'Security' },
          ] as const
        ).map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setCategory(cat.id)}
            className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              category === cat.id
                ? 'bg-blue-600 text-white'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filtered.map((tool) => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              type="button"
              onClick={() => onOpenTool(tool.id)}
              className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 p-4 text-left hover:border-blue-500 dark:hover:border-blue-500 active:scale-[0.99] transition-all flex items-start gap-3.5"
            >
              <div className="w-11 h-11 rounded-xl bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white">
                  {tool.title}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {tool.desc}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
