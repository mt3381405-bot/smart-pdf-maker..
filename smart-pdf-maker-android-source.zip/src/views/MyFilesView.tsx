import React, { useState } from 'react';
import {
  Download,
  Edit3,
  FileText,
  FolderOpen,
  Lock,
  Pencil,
  Search,
  Share2,
  Trash2,
  Upload,
} from 'lucide-react';
import { StoredFile } from '../types';
import { TranslationStrings } from '../i18n/translations';
import {
  formatBytes,
  formatRelativeDate,
  saveBytesToDevice,
  shareFileNative,
} from '../services/fileStorage';

interface MyFilesViewProps {
  t: TranslationStrings;
  files: StoredFile[];
  onOpenFile: (file: StoredFile) => void;
  onEditFile: (file: StoredFile) => void;
  onRenameFile: (id: string, newName: string) => Promise<void>;
  onDeleteFile: (id: string) => Promise<void>;
  onImportFiles: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
}

type FileTab = 'all' | 'recent' | 'created' | 'downloaded';

export const MyFilesView: React.FC<MyFilesViewProps> = ({
  t,
  files,
  onOpenFile,
  onEditFile,
  onRenameFile,
  onDeleteFile,
  onImportFiles,
  onNotify,
}) => {
  const [tab, setTab] = useState<FileTab>('all');
  const [search, setSearch] = useState('');
  const [renamingFile, setRenamingFile] = useState<StoredFile | null>(null);
  const [renameText, setRenameText] = useState('');
  const [deletingFile, setDeletingFile] = useState<StoredFile | null>(null);

  const filtered = files.filter((f) => {
    const q = search.trim().toLowerCase();
    if (q && !f.name.toLowerCase().includes(q)) return false;
    if (tab === 'created') return f.category === 'created';
    if (tab === 'downloaded') return f.category === 'downloaded';
    return true;
  });

  const sorted =
    tab === 'recent'
      ? [...filtered].sort((a, b) => b.lastOpenedAt - a.lastOpenedAt).slice(0, 12)
      : [...filtered].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {t.navFiles}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
            {files.length} local {files.length === 1 ? 'document' : 'documents'} · {formatBytes(files.reduce((s, f) => s + f.size, 0))}
          </p>
        </div>
        <label className="min-h-[42px] px-4 flex items-center gap-2 rounded-xl bg-blue-600 text-xs font-semibold text-white cursor-pointer hover:bg-blue-700">
          <Upload className="w-4 h-4" />
          <span>Import Files</span>
          <input
            type="file"
            accept="application/pdf,.pdf"
            multiple
            className="hidden"
            onChange={onImportFiles}
          />
        </label>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t.searchFiles}
          className="w-full min-h-[44px] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 pl-10 pr-4 text-sm text-slate-900 dark:text-white focus:border-blue-600 focus:outline-none"
        />
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {(
          [
            { id: 'all', label: 'All Files' },
            { id: 'recent', label: 'Recent' },
            { id: 'created', label: 'Created PDFs' },
            { id: 'downloaded', label: 'Downloaded' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              tab === item.id
                ? 'bg-blue-600 text-white'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* File List */}
      {sorted.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 py-14 px-6 text-center">
          <FolderOpen className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto" />
          <p className="mt-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
            No matching files
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Create a PDF with any tool or import an existing PDF from your device.
          </p>
        </div>
      ) : (
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
          {sorted.map((file) => {
            const isPdf = file.mimeType === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
            return (
              <div
                key={file.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <button
                  type="button"
                  onClick={() => (isPdf ? onOpenFile(file) : saveBytesToDevice(file.data, file.name, file.mimeType))}
                  className="flex items-center gap-3.5 min-w-0 text-left flex-1"
                >
                  <div className="w-11 h-11 rounded-xl bg-blue-50 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    {file.isEncrypted ? <Lock className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {file.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                      {formatBytes(file.size)} · {file.pageCount} {file.pageCount === 1 ? 'page' : 'pages'} · {file.category} · {formatRelativeDate(file.createdAt)}
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
                  {isPdf && (
                    <button
                      type="button"
                      onClick={() => onEditFile(file)}
                      className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                      title="Edit PDF"
                      aria-label="Edit PDF"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setRenamingFile(file);
                      setRenameText(file.name);
                    }}
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                    title={t.rename}
                    aria-label={t.rename}
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await shareFileNative(file.data, file.name, file.mimeType);
                      if (res === 'fallback-downloaded') {
                        onNotify('info', 'File saved for sharing', file.name);
                      }
                    }}
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                    title={t.share}
                    aria-label={t.share}
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await saveBytesToDevice(file.data, file.name, file.mimeType);
                      if (res !== 'cancelled') {
                        onNotify('success', 'Saved to device', file.name);
                      }
                    }}
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50"
                    title={t.saveToDevice}
                    aria-label={t.saveToDevice}
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeletingFile(file)}
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    title={t.delete}
                    aria-label={t.delete}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Rename Modal */}
      {renamingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (!renameText.trim()) return;
              await onRenameFile(renamingFile.id, renameText.trim());
              setRenamingFile(null);
            }}
            className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xl"
          >
            <h3 className="text-base font-bold text-slate-900 dark:text-white">{t.rename}</h3>
            <input
              type="text"
              value={renameText}
              onChange={(e) => setRenameText(e.target.value)}
              autoFocus
              className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm"
            />
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setRenamingFile(null)}
                className="flex-1 min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                className="flex-1 min-h-[42px] rounded-xl bg-blue-600 text-sm font-semibold text-white"
              >
                {t.confirm}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Delete Document?</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Remove <strong>{deletingFile.name}</strong> from local storage? This cannot be undone.
            </p>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setDeletingFile(null)}
                className="flex-1 min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await onDeleteFile(deletingFile.id);
                  setDeletingFile(null);
                }}
                className="flex-1 min-h-[42px] rounded-xl bg-rose-600 text-sm font-semibold text-white"
              >
                {t.delete}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
