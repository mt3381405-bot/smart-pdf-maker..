import React, { useState } from 'react';
import {
  Download,
  FileArchive,
  FolderOpen,
  Loader2,
  Upload,
} from 'lucide-react';
import { AppSettings, CompressionLevel, StoredFile } from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  compressPdf,
  getPdfPageCount,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { StoredFilePickerModal } from '../components/StoredFilePickerModal';
import { PasswordPromptModal } from '../components/PasswordPromptModal';

interface CompressorToolProps {
  settings: AppSettings;
  storedFiles: StoredFile[];
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

export const CompressorTool: React.FC<CompressorToolProps> = ({
  settings,
  storedFiles,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [sourceBytes, setSourceBytes] = useState<Uint8Array | null>(null);
  const [fileName, setFileName] = useState('');
  const [pageCount, setPageCount] = useState(0);
  const [password, setPassword] = useState<string | undefined>(undefined);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | undefined>(undefined);

  const [level, setLevel] = useState<CompressionLevel>(settings.defaultCompression);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showPicker, setShowPicker] = useState(false);

  const [result, setResult] = useState<{
    file: StoredFile;
    originalSize: number;
    compressedSize: number;
  } | null>(null);

  const loadSource = async (bytes: Uint8Array, name: string, pw?: string) => {
    setSourceBytes(bytes);
    setFileName(name);
    setResult(null);
    try {
      const info = await getPdfPageCount(bytes, pw);
      setPageCount(info.pageCount);
      setPassword(pw);
      setNeedsPassword(false);
      setPasswordError(undefined);
    } catch (err) {
      if (err instanceof PasswordRequiredError) {
        setNeedsPassword(true);
        setPasswordError(undefined);
      } else if (err instanceof IncorrectPasswordError) {
        setNeedsPassword(true);
        setPasswordError('Incorrect password. Please try again.');
      } else {
        onNotify('error', 'Failed to read PDF', (err as Error).message);
      }
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await loadSource(new Uint8Array(await file.arrayBuffer()), file.name);
    e.target.value = '';
  };

  const handleCompress = async () => {
    if (!sourceBytes) return;
    setProcessing(true);
    setProgress(0);
    try {
      const res = await compressPdf(sourceBytes, level, password, setProgress);
      const outName = fileName.replace(/\.pdf$/i, '') + '_compressed.pdf';
      const saved = await onSaveFile({
        name: outName,
        size: res.compressedSize,
        pageCount: res.pageCount,
        category: 'created',
        mimeType: 'application/pdf',
        data: res.bytes,
        sourceTool: 'PDF Compressor',
      });
      setResult({
        file: saved,
        originalSize: res.originalSize,
        compressedSize: res.compressedSize,
      });
      onNotify(
        'success',
        'Compression complete',
        `${formatBytes(res.originalSize)} → ${formatBytes(res.compressedSize)}`
      );
    } catch (err) {
      onNotify('error', 'Compression failed', (err as Error).message);
    } finally {
      setProcessing(false);
    }
  };

  const reductionPct = result
    ? Math.max(0, Math.round(((result.originalSize - result.compressedSize) / Math.max(1, result.originalSize)) * 100))
    : 0;

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title="PDF Compressor"
        subtitle="Reduce file size with Low, Medium, or High compression"
        onBack={onBack}
      />

      {needsPassword && sourceBytes && (
        <PasswordPromptModal
          fileName={fileName}
          errorMessage={passwordError}
          onSubmit={(pw) => loadSource(sourceBytes, fileName, pw)}
          onCancel={() => {
            setNeedsPassword(false);
            setSourceBytes(null);
          }}
        />
      )}

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <label className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
              <Upload className="w-4 h-4" />
              <span>Select PDF File</span>
              <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={handleUpload} />
            </label>
            <button
              type="button"
              onClick={() => setShowPicker(true)}
              className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-4 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <FolderOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Choose from My Files</span>
            </button>
          </div>

          {sourceBytes && (
            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {fileName}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                  Original size: {formatBytes(sourceBytes.byteLength)} · {pageCount} {pageCount === 1 ? 'page' : 'pages'}
                </p>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Compression Level
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {(
                [
                  { id: 'low', title: 'Low', desc: 'High clarity · lighter reduction' },
                  { id: 'medium', title: 'Medium', desc: 'Balanced quality & size' },
                  { id: 'high', title: 'High', desc: 'Maximum space savings' },
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setLevel(opt.id)}
                  className={`rounded-xl border p-3.5 text-left transition-colors ${
                    level === opt.id
                      ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/40'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <p className="text-sm font-bold text-slate-900 dark:text-white">{opt.title}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{opt.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {processing && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
                <span>Optimizing PDF...</span>
                <span className="font-mono-nums">{progress}%</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-blue-600 transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          <button
            type="button"
            disabled={!sourceBytes || processing}
            onClick={handleCompress}
            className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
          >
            {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileArchive className="w-4 h-4" />}
            <span>Compress PDF</span>
          </button>
        </div>

        {result && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Compression Summary
              </h3>
              <span className="text-sm font-mono-nums font-bold text-emerald-600 dark:text-emerald-400">
                -{reductionPct}% saved
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-slate-50 dark:bg-slate-950 p-3.5">
                <p className="text-xs text-slate-500 dark:text-slate-400">Original Size</p>
                <p className="mt-1 text-lg font-bold font-mono-nums text-slate-900 dark:text-white">
                  {formatBytes(result.originalSize)}
                </p>
              </div>
              <div className="rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 p-3.5">
                <p className="text-xs text-emerald-700 dark:text-emerald-400">Compressed Size</p>
                <p className="mt-1 text-lg font-bold font-mono-nums text-emerald-700 dark:text-emerald-300">
                  {formatBytes(result.compressedSize)}
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => onOpenViewer(result.file)}
                className="flex-1 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-800 dark:text-slate-100"
              >
                Open PDF
              </button>
              <button
                type="button"
                onClick={() => saveBytesToDevice(result.file.data, result.file.name)}
                className="flex-1 min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700"
              >
                <Download className="w-4 h-4" />
                <span>Save Compressed PDF</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {showPicker && (
        <StoredFilePickerModal
          files={storedFiles}
          onClose={() => setShowPicker(false)}
          onSelect={(f) => {
            setShowPicker(false);
            loadSource(f.data, f.name);
          }}
        />
      )}
    </div>
  );
};
