import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Camera,
  Check,
  Crop,
  Download,
  FilePlus2,
  ImagePlus,
  Loader2,
  RotateCw,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import {
  AppSettings,
  CropRect,
  ImageFilter,
  ImageItem,
  PageOrientation,
  PageSizePreset,
  StoredFile,
} from '../types';
import {
  imagesToPdf,
  loadImageElement,
  processImageTransform,
  readFileAsDataUrl,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { CameraModal } from '../components/CameraModal';

interface ImageToPdfToolProps {
  title?: string;
  acceptMime?: string;
  settings: AppSettings;
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

export const ImageToPdfTool: React.FC<ImageToPdfToolProps> = ({
  title = 'Image to PDF',
  acceptMime = 'image/*',
  settings,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [items, setItems] = useState<ImageItem[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);

  const [pageSize, setPageSize] = useState<PageSizePreset>(settings.defaultPageSize);
  const [orientation, setOrientation] = useState<PageOrientation>(settings.defaultOrientation);
  const [customWidthMm, setCustomWidthMm] = useState(210);
  const [customHeightMm, setCustomHeightMm] = useState(297);
  const [outputName, setOutputName] = useState(`Images_${new Date().toISOString().slice(0, 10)}.pdf`);

  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [resultFile, setResultFile] = useState<StoredFile | null>(null);

  const editingItem = items.find((it) => it.id === editingId) || null;

  const addDataUrl = async (dataUrl: string, name: string) => {
    const img = await loadImageElement(dataUrl);
    const id = `img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const newItem: ImageItem = {
      id,
      name,
      originalDataUrl: dataUrl,
      processedDataUrl: dataUrl,
      rotation: 0,
      filter: 'original',
      crop: { x: 0, y: 0, w: 1, h: 1 },
      width: img.naturalWidth,
      height: img.naturalHeight,
    };
    setItems((prev) => [...prev, newItem]);
  };

  const handleSelectFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    try {
      for (const file of files) {
        const dataUrl = await readFileAsDataUrl(file);
        await addDataUrl(dataUrl, file.name);
      }
      setResultFile(null);
    } catch (err) {
      onNotify('error', 'Could not load image', (err as Error).message);
    }
    e.target.value = '';
  };

  const moveItem = (index: number, delta: number) => {
    const target = index + delta;
    if (target < 0 || target >= items.length) return;
    setItems((prev) => {
      const next = [...prev];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
    if (editingId === id) setEditingId(null);
  };

  const updateItemTransform = async (
    id: string,
    patch: Partial<{ rotation: number; filter: ImageFilter; crop: CropRect }>
  ) => {
    const current = items.find((i) => i.id === id);
    if (!current) return;
    const nextRotation = patch.rotation ?? current.rotation;
    const nextFilter = patch.filter ?? current.filter;
    const nextCrop = patch.crop ?? current.crop;
    const res = await processImageTransform(
      current.originalDataUrl,
      nextRotation,
      nextFilter,
      nextCrop
    );
    setItems((prev) =>
      prev.map((it) =>
        it.id === id
          ? {
              ...it,
              rotation: nextRotation,
              filter: nextFilter,
              crop: nextCrop,
              processedDataUrl: res.dataUrl,
              width: res.width,
              height: res.height,
            }
          : it
      )
    );
  };

  const handleCreatePdf = async () => {
    if (items.length === 0) return;
    setProcessing(true);
    setProgress(5);
    try {
      const mmToPt = (mm: number) => (mm * 72) / 25.4;
      const bytes = await imagesToPdf(
        items,
        {
          pageSize,
          orientation,
          customWidthPt: mmToPt(customWidthMm),
          customHeightPt: mmToPt(customHeightMm),
        },
        setProgress
      );
      const finalName = outputName.toLowerCase().endsWith('.pdf')
        ? outputName
        : `${outputName}.pdf`;
      const saved = await onSaveFile({
        name: finalName,
        size: bytes.byteLength,
        pageCount: items.length,
        category: 'created',
        mimeType: 'application/pdf',
        data: bytes,
        sourceTool: title,
      });
      setResultFile(saved);
      onNotify('success', 'PDF created successfully', `${finalName} · ${formatBytes(bytes.byteLength)}`);
    } catch (err) {
      onNotify('error', 'Failed to create PDF', (err as Error).message);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title={title}
        subtitle="Select images, crop, rotate, filter & export PDF"
        onBack={onBack}
      />

      <div className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-5">
          {/* Import Bar */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap items-center gap-3">
            <label className="flex-1 min-w-[160px] min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700 active:scale-[0.98] transition-all">
              <ImagePlus className="w-4 h-4" />
              <span>Select Images</span>
              <input
                type="file"
                accept={acceptMime}
                multiple
                className="hidden"
                onChange={handleSelectFiles}
              />
            </label>
            <button
              type="button"
              onClick={() => setShowCamera(true)}
              className="min-h-[44px] px-4 flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <Camera className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Camera</span>
            </button>
          </div>

          {/* Image List */}
          {items.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 bg-white/60 dark:bg-slate-900/40 py-14 px-6 text-center">
              <ImagePlus className="w-11 h-11 text-blue-600/70 dark:text-blue-400/70 mx-auto" />
              <h3 className="mt-3 text-base font-bold text-slate-900 dark:text-white">
                No images selected yet
              </h3>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                Add photos from your gallery or capture directly with the camera. You can reorder, crop, rotate, and apply filters before generating your PDF.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {items.map((item, idx) => (
                <div
                  key={item.id}
                  className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col"
                >
                  <div className="relative aspect-[4/3] bg-slate-100 dark:bg-slate-950 flex items-center justify-center overflow-hidden">
                    <img
                      src={item.processedDataUrl}
                      alt={item.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  <div className="p-3.5 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {idx + 1}. {item.name}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                          {item.width} × {item.height}px · {item.filter}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => moveItem(idx, -1)}
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === items.length - 1}
                          onClick={() => moveItem(idx, 1)}
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => updateItemTransform(item.id, { rotation: (item.rotation + 90) % 360 })}
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                          aria-label="Rotate 90 degrees"
                        >
                          <RotateCw className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setEditingId(item.id)}
                          className="min-h-[38px] px-2.5 flex items-center gap-1.5 rounded-lg text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                          <span>Crop & Filter</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => removeItem(item.id)}
                          className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          aria-label="Remove image"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Page Settings & Export Panel */}
        <div className="lg:col-span-4 space-y-4">
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              PDF Page Setup
            </h2>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                File Name
              </label>
              <input
                type="text"
                value={outputName}
                onChange={(e) => setOutputName(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-white focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                Page Size
              </label>
              <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
                {(['A4', 'A3', 'Letter', 'Custom'] as PageSizePreset[]).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setPageSize(sz)}
                    className={`min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
                      pageSize === sz
                        ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {pageSize === 'Custom' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                    Width (mm)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={1200}
                    value={customWidthMm}
                    onChange={(e) => setCustomWidthMm(Number(e.target.value) || 210)}
                    className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm font-mono-nums"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                    Height (mm)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={1500}
                    value={customHeightMm}
                    onChange={(e) => setCustomHeightMm(Number(e.target.value) || 297)}
                    className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm font-mono-nums"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                Orientation
              </label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
                {(['portrait', 'landscape'] as PageOrientation[]).map((ori) => (
                  <button
                    key={ori}
                    type="button"
                    onClick={() => setOrientation(ori)}
                    className={`min-h-[38px] rounded-lg text-xs font-semibold capitalize transition-colors ${
                      orientation === ori
                        ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {ori}
                  </button>
                ))}
              </div>
            </div>

            {processing && (
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
                  <span>Building PDF...</span>
                  <span className="font-mono-nums">{progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-blue-600 transition-all duration-200"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )}

            <button
              type="button"
              disabled={items.length === 0 || processing}
              onClick={handleCreatePdf}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40 active:scale-[0.98] transition-all"
            >
              {processing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FilePlus2 className="w-4 h-4" />
              )}
              <span>Create PDF ({items.length})</span>
            </button>
          </div>

          {resultFile && (
            <div className="rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 space-y-3">
              <div>
                <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                  PDF Ready
                </p>
                <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono-nums">
                  {resultFile.name} · {formatBytes(resultFile.size)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onOpenViewer(resultFile)}
                  className="flex-1 min-h-[42px] rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-200"
                >
                  Open PDF
                </button>
                <button
                  type="button"
                  onClick={() => saveBytesToDevice(resultFile.data, resultFile.name)}
                  className="flex-1 min-h-[42px] flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 text-xs font-semibold text-white hover:bg-emerald-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Save to Device</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Crop & Filter Editor Modal */}
      {editingItem && (
        <ImageCropFilterModal
          item={editingItem}
          onClose={() => setEditingId(null)}
          onApply={async (patch) => {
            await updateItemTransform(editingItem.id, patch);
            setEditingId(null);
          }}
        />
      )}

      {showCamera && (
        <CameraModal
          title="Capture Photo for PDF"
          onClose={() => setShowCamera(false)}
          onCapture={async (dataUrl, name) => {
            await addDataUrl(dataUrl, name);
            setShowCamera(false);
          }}
        />
      )}
    </div>
  );
};

const ImageCropFilterModal: React.FC<{
  item: ImageItem;
  onClose: () => void;
  onApply: (patch: { rotation: number; filter: ImageFilter; crop: CropRect }) => Promise<void>;
}> = ({ item, onClose, onApply }) => {
  const [rotation, setRotation] = useState(item.rotation);
  const [filter, setFilter] = useState<ImageFilter>(item.filter);
  const [crop, setCrop] = useState<CropRect>(item.crop);
  const [saving, setSaving] = useState(false);

  const filterCss: Record<ImageFilter, string> = {
    original: 'none',
    grayscale: 'grayscale(100%)',
    bw: 'grayscale(100%) contrast(200%) brightness(110%)',
    enhance: 'contrast(125%) brightness(105%) saturate(110%)',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Crop className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Crop, Rotate & Filter
            </h3>
          </div>
          <button
            type="button"
            onClick={() => setRotation((r) => (r + 90) % 360)}
            className="min-h-[36px] px-3 flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Rotate 90°</span>
          </button>
        </div>

        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          <div className="relative bg-slate-100 dark:bg-slate-950 rounded-xl p-3 flex items-center justify-center min-h-[220px] max-h-[300px] overflow-hidden">
            <div className="relative inline-block max-h-[260px]">
              <img
                src={item.originalDataUrl}
                alt={item.name}
                style={{
                  transform: `rotate(${rotation}deg)`,
                  filter: filterCss[filter],
                }}
                className="max-h-[250px] w-auto object-contain transition-transform"
              />
              <div
                className="absolute border-2 border-blue-500 bg-blue-500/10 pointer-events-none"
                style={{
                  left: `${crop.x * 100}%`,
                  top: `${crop.y * 100}%`,
                  width: `${crop.w * 100}%`,
                  height: `${crop.h * 100}%`,
                }}
              />
            </div>
          </div>

          {/* Filter Picker */}
          <div>
            <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-2">
              Image Filter
            </p>
            <div className="grid grid-cols-4 gap-2">
              {(
                [
                  { id: 'original', label: 'Original' },
                  { id: 'enhance', label: 'Color+' },
                  { id: 'grayscale', label: 'Grayscale' },
                  { id: 'bw', label: 'B&W Doc' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFilter(f.id)}
                  className={`min-h-[40px] rounded-xl text-xs font-semibold border transition-colors ${
                    filter === f.id
                      ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Crop Sliders */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <label className="space-y-1">
              <span className="text-slate-500 dark:text-slate-400">Left Margin ({Math.round(crop.x * 100)}%)</span>
              <input
                type="range"
                min={0}
                max={0.45}
                step={0.01}
                value={crop.x}
                onChange={(e) => {
                  const nx = Number(e.target.value);
                  setCrop((c) => ({ ...c, x: nx, w: Math.min(c.w, 1 - nx) }));
                }}
                className="w-full accent-blue-600"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-500 dark:text-slate-400">Top Margin ({Math.round(crop.y * 100)}%)</span>
              <input
                type="range"
                min={0}
                max={0.45}
                step={0.01}
                value={crop.y}
                onChange={(e) => {
                  const ny = Number(e.target.value);
                  setCrop((c) => ({ ...c, y: ny, h: Math.min(c.h, 1 - ny) }));
                }}
                className="w-full accent-blue-600"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-500 dark:text-slate-400">Crop Width ({Math.round(crop.w * 100)}%)</span>
              <input
                type="range"
                min={0.2}
                max={1 - crop.x}
                step={0.01}
                value={crop.w}
                onChange={(e) => setCrop((c) => ({ ...c, w: Number(e.target.value) }))}
                className="w-full accent-blue-600"
              />
            </label>
            <label className="space-y-1">
              <span className="text-slate-500 dark:text-slate-400">Crop Height ({Math.round(crop.h * 100)}%)</span>
              <input
                type="range"
                min={0.2}
                max={1 - crop.y}
                step={0.01}
                value={crop.h}
                onChange={(e) => setCrop((c) => ({ ...c, h: Number(e.target.value) }))}
                className="w-full accent-blue-600"
              />
            </label>
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-700 dark:text-slate-200"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={async () => {
              setSaving(true);
              await onApply({ rotation, filter, crop });
              setSaving(false);
            }}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-1.5 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700"
          >
            <Check className="w-4 h-4" />
            <span>Apply Changes</span>
          </button>
        </div>
      </div>
    </div>
  );
};
