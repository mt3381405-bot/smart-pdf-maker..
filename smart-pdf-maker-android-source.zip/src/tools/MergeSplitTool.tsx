import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  Download,
  FolderOpen,
  Loader2,
  Merge,
  Scissors,
  Trash2,
  Upload,
} from 'lucide-react';
import { StoredFile } from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  mergePdfs,
  parsePageRangeGroups,
  renderAllPdfThumbnails,
  splitPdf,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { StoredFilePickerModal } from '../components/StoredFilePickerModal';
import { PasswordPromptModal } from '../components/PasswordPromptModal';

interface MergeSplitToolProps {
  initialTab: 'merge' | 'split';
  storedFiles: StoredFile[];
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

interface MergeItem {
  id: string;
  name: string;
  bytes: Uint8Array;
  password?: string;
  thumbs: Array<{ dataUrl: string }>;
  selectedPages: number[];
}

export const MergeSplitTool: React.FC<MergeSplitToolProps> = ({
  initialTab,
  storedFiles,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [tab, setTab] = useState<'merge' | 'split'>(initialTab);

  // Merge state
  const [mergeItems, setMergeItems] = useState<MergeItem[]>([]);
  const [mergeOutputName, setMergeOutputName] = useState(`Merged_${new Date().toISOString().slice(0, 10)}.pdf`);
  const [mergedResult, setMergedResult] = useState<StoredFile | null>(null);

  // Split state
  const [splitSource, setSplitSource] = useState<{
    name: string;
    bytes: Uint8Array;
    password?: string;
    thumbs: Array<{ dataUrl: string }>;
  } | null>(null);
  const [splitMode, setSplitMode] = useState<'ranges' | 'selected' | 'every'>('ranges');
  const [rangeInput, setRangeInput] = useState('1-2');
  const [splitSelected, setSplitSelected] = useState<number[]>([]);
  const [splitResults, setSplitResults] = useState<StoredFile[]>([]);

  // Shared UI state
  const [loading, setLoading] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [pickerTarget, setPickerTarget] = useState<'merge' | 'split' | null>(null);
  const [pendingPw, setPendingPw] = useState<{
    target: 'merge' | 'split';
    bytes: Uint8Array;
    name: string;
    error?: string;
  } | null>(null);

  const ingestPdf = async (
    target: 'merge' | 'split',
    bytes: Uint8Array,
    name: string,
    pw?: string
  ) => {
    setLoading(true);
    try {
      const thumbs = await renderAllPdfThumbnails(bytes, 0.28, pw);
      const allIndices = thumbs.map((_, i) => i);
      if (target === 'merge') {
        setMergeItems((prev) => [
          ...prev,
          {
            id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            name,
            bytes,
            password: pw,
            thumbs,
            selectedPages: allIndices,
          },
        ]);
        setMergedResult(null);
      } else {
        setSplitSource({ name, bytes, password: pw, thumbs });
        setSplitSelected(allIndices);
        setRangeInput(thumbs.length > 1 ? `1-${Math.ceil(thumbs.length / 2)}, ${Math.ceil(thumbs.length / 2) + 1}-${thumbs.length}` : '1');
        setSplitResults([]);
      }
      setPendingPw(null);
    } catch (err) {
      if (err instanceof PasswordRequiredError) {
        setPendingPw({ target, bytes, name });
      } else if (err instanceof IncorrectPasswordError) {
        setPendingPw({ target, bytes, name, error: 'Incorrect password. Please try again.' });
      } else {
        onNotify('error', 'Failed to open PDF', (err as Error).message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (target: 'merge' | 'split', e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    for (const f of files) {
      await ingestPdf(target, new Uint8Array(await f.arrayBuffer()), f.name);
    }
    e.target.value = '';
  };

  const toggleMergePage = (itemId: string, pageIdx: number) => {
    setMergeItems((prev) =>
      prev.map((item) => {
        if (item.id !== itemId) return item;
        const exists = item.selectedPages.includes(pageIdx);
        const next = exists
          ? item.selectedPages.filter((p) => p !== pageIdx)
          : [...item.selectedPages, pageIdx].sort((a, b) => a - b);
        return { ...item, selectedPages: next };
      })
    );
  };

  const handleMerge = async () => {
    const totalSelected = mergeItems.reduce((acc, it) => acc + it.selectedPages.length, 0);
    if (totalSelected === 0) {
      onNotify('error', 'Select at least one page to merge');
      return;
    }
    setProcessing(true);
    try {
      const bytes = await mergePdfs(
        mergeItems.map((it) => ({
          bytes: it.bytes,
          selectedPages: it.selectedPages,
          password: it.password,
        }))
      );
      const finalName = mergeOutputName.toLowerCase().endsWith('.pdf')
        ? mergeOutputName
        : `${mergeOutputName}.pdf`;
      const saved = await onSaveFile({
        name: finalName,
        size: bytes.byteLength,
        pageCount: totalSelected,
        category: 'created',
        mimeType: 'application/pdf',
        data: bytes,
        sourceTool: 'Merge PDF',
      });
      setMergedResult(saved);
      onNotify('success', 'PDFs merged successfully', `${finalName} · ${totalSelected} pages`);
    } catch (err) {
      onNotify('error', 'Merge failed', (err as Error).message);
    } finally {
      setProcessing(false);
    }
  };

  const handleSplit = async () => {
    if (!splitSource) return;
    const total = splitSource.thumbs.length;
    let groups: number[][] = [];
    if (splitMode === 'ranges') {
      groups = parsePageRangeGroups(rangeInput, total);
    } else if (splitMode === 'selected') {
      if (splitSelected.length) groups = [splitSelected];
    } else {
      groups = Array.from({ length: total }, (_, i) => [i]);
    }

    if (groups.length === 0) {
      onNotify('error', 'Enter a valid page range or select pages');
      return;
    }

    setProcessing(true);
    try {
      const outputs = await splitPdf(
        splitSource.bytes,
        groups,
        splitSource.name,
        splitSource.password
      );
      const savedList: StoredFile[] = [];
      for (const out of outputs) {
        const saved = await onSaveFile({
          name: out.name,
          size: out.bytes.byteLength,
          pageCount: out.pageCount,
          category: 'created',
          mimeType: 'application/pdf',
          data: out.bytes,
          sourceTool: 'Split PDF',
        });
        savedList.push(saved);
      }
      setSplitResults(savedList);
      onNotify('success', `Split into ${savedList.length} PDF file(s)`);
    } catch (err) {
      onNotify('error', 'Split failed', (err as Error).message);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title={tab === 'merge' ? 'Merge PDF' : 'Split PDF'}
        subtitle="Combine multiple PDFs or split by page range"
        onBack={onBack}
      />

      {pendingPw && (
        <PasswordPromptModal
          fileName={pendingPw.name}
          errorMessage={pendingPw.error}
          onSubmit={(pw) => ingestPdf(pendingPw.target, pendingPw.bytes, pendingPw.name, pw)}
          onCancel={() => setPendingPw(null)}
        />
      )}

      <div className="max-w-5xl mx-auto px-4 py-6 space-y-5">
        {/* Segmented Control */}
        <div className="max-w-xs grid grid-cols-2 gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl">
          <button
            type="button"
            onClick={() => setTab('merge')}
            className={`min-h-[40px] flex items-center justify-center gap-1.5 rounded-lg text-xs font-bold transition-colors ${
              tab === 'merge'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Merge className="w-3.5 h-3.5" />
            <span>Merge PDF</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('split')}
            className={`min-h-[40px] flex items-center justify-center gap-1.5 rounded-lg text-xs font-bold transition-colors ${
              tab === 'split'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Scissors className="w-3.5 h-3.5" />
            <span>Split PDF</span>
          </button>
        </div>

        {tab === 'merge' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-8 space-y-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap gap-3">
                <label className="flex-1 min-w-[160px] min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
                  <Upload className="w-4 h-4" />
                  <span>Add PDF Files</span>
                  <input
                    type="file"
                    accept="application/pdf,.pdf"
                    multiple
                    className="hidden"
                    onChange={(e) => handleUpload('merge', e)}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => setPickerTarget('merge')}
                  className="min-h-[44px] px-4 flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <FolderOpen className="w-4 h-4 text-blue-600" />
                  <span>My Files</span>
                </button>
              </div>

              {loading && (
                <div className="flex items-center gap-2 text-sm text-blue-600 font-medium">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Loading PDF pages...</span>
                </div>
              )}

              {mergeItems.length === 0 ? (
                <div className="rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 py-12 px-6 text-center text-sm text-slate-500 dark:text-slate-400">
                  Add two or more PDFs above. You can select specific pages from each file and reorder them.
                </div>
              ) : (
                mergeItems.map((item, idx) => (
                  <div
                    key={item.id}
                    className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                          {idx + 1}. {item.name}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                          {item.selectedPages.length} of {item.thumbs.length} pages selected · {formatBytes(item.bytes.byteLength)}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={() => {
                            const next = [...mergeItems];
                            [next[idx], next[idx - 1]] = [next[idx - 1], next[idx]];
                            setMergeItems(next);
                          }}
                          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === mergeItems.length - 1}
                          onClick={() => {
                            const next = [...mergeItems];
                            [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
                            setMergeItems(next);
                          }}
                          className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setMergeItems((prev) => prev.filter((x) => x.id !== item.id))}
                          className="p-2 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      {item.thumbs.map((t, pIdx) => {
                        const selected = item.selectedPages.includes(pIdx);
                        return (
                          <button
                            key={pIdx}
                            type="button"
                            onClick={() => toggleMergePage(item.id, pIdx)}
                            className={`relative rounded-xl border overflow-hidden aspect-[3/4] transition-all ${
                              selected
                                ? 'border-blue-600 ring-2 ring-blue-600/20'
                                : 'border-slate-200 dark:border-slate-800 opacity-50'
                            }`}
                          >
                            <img src={t.dataUrl} alt={`Page ${pIdx + 1}`} className="w-full h-full object-cover" />
                            <span className="absolute bottom-1 left-1 px-1.5 rounded bg-slate-950/75 text-[10px] font-mono-nums text-white">
                              {pIdx + 1}
                            </span>
                            {selected && (
                              <span className="absolute top-1 right-1 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center">
                                <Check className="w-3 h-3" />
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="lg:col-span-4 space-y-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Merge Settings</h3>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                    Merged File Name
                  </label>
                  <input
                    type="text"
                    value={mergeOutputName}
                    onChange={(e) => setMergeOutputName(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm"
                  />
                </div>
                <button
                  type="button"
                  disabled={mergeItems.length === 0 || processing}
                  onClick={handleMerge}
                  className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
                >
                  {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Merge className="w-4 h-4" />}
                  <span>Merge PDFs</span>
                </button>
              </div>

              {mergedResult && (
                <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 space-y-3">
                  <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                    {mergedResult.name}
                  </p>
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono-nums">
                    {formatBytes(mergedResult.size)} · {mergedResult.pageCount} pages
                  </p>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenViewer(mergedResult)}
                      className="flex-1 min-h-[40px] rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-200"
                    >
                      Open
                    </button>
                    <button
                      type="button"
                      onClick={() => saveBytesToDevice(mergedResult.data, mergedResult.name)}
                      className="flex-1 min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 text-xs font-semibold text-white"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Save</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            <div className="lg:col-span-8 space-y-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap gap-3">
                <label className="flex-1 min-w-[160px] min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
                  <Upload className="w-4 h-4" />
                  <span>Select PDF to Split</span>
                  <input
                    type="file"
                    accept="application/pdf,.pdf"
                    className="hidden"
                    onChange={(e) => handleUpload('split', e)}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => setPickerTarget('split')}
                  className="min-h-[44px] px-4 flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <FolderOpen className="w-4 h-4 text-blue-600" />
                  <span>My Files</span>
                </button>
              </div>

              {splitSource && (
                <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
                  <div>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">
                      {splitSource.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                      {splitSource.thumbs.length} pages · {formatBytes(splitSource.bytes.byteLength)}
                    </p>
                  </div>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                    {splitSource.thumbs.map((t, idx) => {
                      const active = splitSelected.includes(idx);
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() =>
                            setSplitSelected((prev) =>
                              prev.includes(idx)
                                ? prev.filter((p) => p !== idx)
                                : [...prev, idx].sort((a, b) => a - b)
                            )
                          }
                          className={`relative rounded-xl border overflow-hidden aspect-[3/4] ${
                            splitMode !== 'selected' || active
                              ? 'border-blue-600'
                              : 'border-slate-200 dark:border-slate-800 opacity-45'
                          }`}
                        >
                          <img src={t.dataUrl} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                          <span className="absolute bottom-1 left-1 px-1.5 rounded bg-slate-950/75 text-[10px] font-mono-nums text-white">
                            {idx + 1}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <div className="lg:col-span-4 space-y-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Split Options</h3>
                <div className="space-y-2">
                  {(
                    [
                      { id: 'ranges', label: 'Split by Page Ranges' },
                      { id: 'selected', label: 'Extract Selected Pages' },
                      { id: 'every', label: 'Split Every Page' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSplitMode(opt.id)}
                      className={`w-full min-h-[42px] px-3.5 rounded-xl border text-left text-xs font-semibold transition-colors ${
                        splitMode === opt.id
                          ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300'
                          : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>

                {splitMode === 'ranges' && (
                  <div>
                    <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                      Ranges (comma-separated, e.g. 1-3, 4-6)
                    </label>
                    <input
                      type="text"
                      value={rangeInput}
                      onChange={(e) => setRangeInput(e.target.value)}
                      placeholder="1-3, 4-6"
                      className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm font-mono-nums"
                    />
                  </div>
                )}

                <button
                  type="button"
                  disabled={!splitSource || processing}
                  onClick={handleSplit}
                  className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
                >
                  {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Scissors className="w-4 h-4" />}
                  <span>Split PDF</span>
                </button>
              </div>

              {splitResults.length > 0 && (
                <div className="rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 p-4 space-y-2.5">
                  <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                    Created {splitResults.length} File(s)
                  </p>
                  {splitResults.map((f) => (
                    <div
                      key={f.id}
                      className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 dark:bg-slate-950 p-2.5"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {f.name}
                        </p>
                        <p className="text-[11px] text-slate-500 font-mono-nums">
                          {f.pageCount}p · {formatBytes(f.size)}
                        </p>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => onOpenViewer(f)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                        >
                          Open
                        </button>
                        <button
                          type="button"
                          onClick={() => saveBytesToDevice(f.data, f.name)}
                          className="px-2.5 py-1.5 rounded-lg bg-blue-600 text-xs font-semibold text-white"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {pickerTarget && (
        <StoredFilePickerModal
          files={storedFiles}
          onClose={() => setPickerTarget(null)}
          onSelect={(f) => {
            const t = pickerTarget;
            setPickerTarget(null);
            ingestPdf(t, f.data, f.name);
          }}
        />
      )}
    </div>
  );
};
