import React, { useState } from 'react';
import {
  Download,
  Eye,
  EyeOff,
  FolderOpen,
  Loader2,
  Lock,
  ShieldCheck,
  Unlock,
  Upload,
} from 'lucide-react';
import { StoredFile } from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  getPdfPageCount,
  protectPdfWithPassword,
  unlockPdfWithPassword,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { StoredFilePickerModal } from '../components/StoredFilePickerModal';

interface SecurityToolProps {
  storedFiles: StoredFile[];
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

export const SecurityTool: React.FC<SecurityToolProps> = ({
  storedFiles,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [tab, setTab] = useState<'protect' | 'unlock'>('protect');
  const [source, setSource] = useState<{ name: string; bytes: Uint8Array } | null>(null);

  // Protect state
  const [userPassword, setUserPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [allowPrinting, setAllowPrinting] = useState(true);
  const [allowCopying, setAllowCopying] = useState(false);

  // Unlock state
  const [unlockPw, setUnlockPw] = useState('');
  const [unlockError, setUnlockError] = useState('');

  const [processing, setProcessing] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [resultFile, setResultFile] = useState<StoredFile | null>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    setSource({ name: file.name, bytes });
    setResultFile(null);
    setUnlockError('');
    e.target.value = '';
  };

  const handleProtect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!source) return;
    if (userPassword.length < 4) {
      onNotify('error', 'Password too short', 'Use at least 4 characters.');
      return;
    }
    if (userPassword !== confirmPassword) {
      onNotify('error', 'Passwords do not match');
      return;
    }
    setProcessing(true);
    try {
      const info = await getPdfPageCount(source.bytes);
      const protectedBytes = await protectPdfWithPassword(
        source.bytes,
        userPassword,
        userPassword,
        { printing: allowPrinting, copying: allowCopying, modifying: false }
      );
      const outName = source.name.replace(/\.pdf$/i, '') + '_protected.pdf';
      const saved = await onSaveFile({
        name: outName,
        size: protectedBytes.byteLength,
        pageCount: info.pageCount,
        category: 'created',
        mimeType: 'application/pdf',
        data: protectedBytes,
        isEncrypted: true,
        sourceTool: 'PDF Password',
      });
      setResultFile(saved);
      setUserPassword('');
      setConfirmPassword('');
      onNotify('success', 'PDF encrypted with AES-256 password', outName);
    } catch (err) {
      onNotify(
        'error',
        'Encryption failed',
        err instanceof PasswordRequiredError
          ? 'This PDF is already password-protected. Unlock it first with its password.'
          : (err as Error).message
      );
    } finally {
      setProcessing(false);
    }
  };

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!source || !unlockPw) return;
    setProcessing(true);
    setUnlockError('');
    try {
      const res = await unlockPdfWithPassword(source.bytes, unlockPw);
      const outName = source.name.replace(/\.pdf$/i, '') + '_unlocked.pdf';
      const saved = await onSaveFile({
        name: outName,
        size: res.bytes.byteLength,
        pageCount: res.pageCount,
        category: 'created',
        mimeType: 'application/pdf',
        data: res.bytes,
        isEncrypted: false,
        sourceTool: 'PDF Password',
      });
      setResultFile(saved);
      setUnlockPw('');
      onNotify('success', 'PDF opened with password', outName);
    } catch (err) {
      if (err instanceof IncorrectPasswordError || err instanceof PasswordRequiredError) {
        setUnlockError('Incorrect password. Passwords cannot be bypassed.');
      } else {
        setUnlockError('Incorrect password or unsupported encryption.');
      }
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title="PDF Password & Security"
        subtitle="AES-256 password protection & verified unlocking"
        onBack={onBack}
      />

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        {/* Segmented Control */}
        <div className="max-w-sm grid grid-cols-2 gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setTab('protect');
              setResultFile(null);
              setUnlockError('');
            }}
            className={`min-h-[40px] flex items-center justify-center gap-1.5 rounded-lg text-xs font-bold ${
              tab === 'protect'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Protect PDF</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('unlock');
              setResultFile(null);
              setUnlockError('');
            }}
            className={`min-h-[40px] flex items-center justify-center gap-1.5 rounded-lg text-xs font-bold ${
              tab === 'unlock'
                ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>Open Protected PDF</span>
          </button>
        </div>

        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <label className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
              <Upload className="w-4 h-4" />
              <span>Select PDF File</span>
              <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={handleUpload} />
            </label>
            <button
              type="button"
              onClick={() => setShowPicker(true)}
              className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-4 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
            >
              <FolderOpen className="w-4 h-4 text-blue-600" />
              <span>My Files</span>
            </button>
          </div>

          {source && (
            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5">
              <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                {source.name}
              </p>
              <p className="text-xs text-slate-500 font-mono-nums">
                {formatBytes(source.bytes.byteLength)}
              </p>
            </div>
          )}

          {tab === 'protect' ? (
            <form onSubmit={handleProtect} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                    Set Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPw ? 'text' : 'password'}
                      value={userPassword}
                      onChange={(e) => setUserPassword(e.target.value)}
                      placeholder="Min 4 characters"
                      className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 pr-10 text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPw((v) => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 p-1"
                    >
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                    Confirm Password
                  </label>
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-4 pt-1">
                <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowPrinting}
                    onChange={(e) => setAllowPrinting(e.target.checked)}
                    className="w-4 h-4 accent-blue-600 rounded"
                  />
                  <span>Allow Printing</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowCopying}
                    onChange={(e) => setAllowCopying(e.target.checked)}
                    className="w-4 h-4 accent-blue-600 rounded"
                  />
                  <span>Allow Copying Text</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={!source || !userPassword || processing}
                className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                <span>Encrypt & Save Protected PDF</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleUnlock} className="space-y-4">
              <div className="rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900 p-3 flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  Smart PDF Maker verifies your exact password locally and never bypasses document encryption.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                  Document Password
                </label>
                <input
                  type="password"
                  value={unlockPw}
                  onChange={(e) => setUnlockPw(e.target.value)}
                  placeholder="Enter the PDF password"
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm"
                />
                {unlockError && (
                  <p className="mt-1.5 text-xs font-medium text-rose-600 dark:text-rose-400">
                    {unlockError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={!source || !unlockPw || processing}
                className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Unlock className="w-4 h-4" />}
                <span>Verify Password & Open</span>
              </button>
            </form>
          )}
        </div>

        {resultFile && (
          <div className="rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 space-y-3">
            <div>
              <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                {resultFile.name}
              </p>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono-nums">
                {formatBytes(resultFile.size)} · {resultFile.pageCount} page(s)
              </p>
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => onOpenViewer(resultFile)}
                className="flex-1 min-h-[42px] rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-200"
              >
                Open PDF
              </button>
              <button
                type="button"
                onClick={() => saveBytesToDevice(resultFile.data, resultFile.name)}
                className="flex-1 min-h-[42px] flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 text-xs font-semibold text-white"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save to Device</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {showPicker && (
        <StoredFilePickerModal
          files={storedFiles}
          onClose={() => setShowPicker(false)}
          onSelect={(f) => {
            setShowPicker(false);
            setSource({ name: f.name, bytes: f.data });
            setResultFile(null);
            setUnlockError('');
          }}
        />
      )}
    </div>
  );
};
