import React, { useRef, useState } from 'react';
import {
  Camera,
  Check,
  Download,
  FilePlus2,
  Loader2,
  ScanLine,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import { ImageFilter, Point2D, ScannedPage, StoredFile } from '../types';
import {
  detectDocumentCorners,
  imagesToPdf,
  perspectiveWarpAndFilter,
  readFileAsDataUrl,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { CameraModal } from '../components/CameraModal';

interface ScannerToolProps {
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

export const ScannerTool: React.FC<ScannerToolProps> = ({
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [pages, setPages] = useState<ScannedPage[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [warping, setWarping] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [outputName, setOutputName] = useState(`Scanned_Doc_${new Date().toISOString().slice(0, 10)}.pdf`);
  const [savedFile, setSavedFile] = useState<StoredFile | null>(null);

  const stageRef = useRef<HTMLDivElement | null>(null);
  const [draggingCorner, setDraggingCorner] = useState<number | null>(null);

  const activePage = pages.find((p) => p.id === activeId) || pages[0] || null;

  const ingestImage = async (dataUrl: string) => {
    setWarping(true);
    try {
      const detected = await detectDocumentCorners(dataUrl);
      const warped = await perspectiveWarpAndFilter(dataUrl, detected, 'enhance');
      const newPage: ScannedPage = {
        id: `scan_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        rawDataUrl: dataUrl,
        processedDataUrl: warped.dataUrl,
        corners: detected,
        filter: 'enhance',
        width: warped.width,
        height: warped.height,
      };
      setPages((prev) => [...prev, newPage]);
      setActiveId(newPage.id);
      setSavedFile(null);
    } catch (err) {
      onNotify('error', 'Scan processing failed', (err as Error).message);
    } finally {
      setWarping(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    for (const f of files) {
      const url = await readFileAsDataUrl(f);
      await ingestImage(url);
    }
    e.target.value = '';
  };

  const handleCornerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (draggingCorner === null || !activePage || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    const nx = Math.max(0.01, Math.min(0.99, (e.clientX - rect.left) / rect.width));
    const ny = Math.max(0.01, Math.min(0.99, (e.clientY - rect.top) / rect.height));
    setPages((prev) =>
      prev.map((p) => {
        if (p.id !== activePage.id) return p;
        const nextCorners = [...p.corners] as [Point2D, Point2D, Point2D, Point2D];
        nextCorners[draggingCorner] = { x: nx, y: ny };
        return { ...p, corners: nextCorners };
      })
    );
  };

  const applyPerspectiveAndFilter = async (targetPage: ScannedPage, filterOverride?: ImageFilter) => {
    setWarping(true);
    try {
      const nextFilter = filterOverride ?? targetPage.filter;
      const warped = await perspectiveWarpAndFilter(
        targetPage.rawDataUrl,
        targetPage.corners,
        nextFilter
      );
      setPages((prev) =>
        prev.map((p) =>
          p.id === targetPage.id
            ? {
                ...p,
                filter: nextFilter,
                processedDataUrl: warped.dataUrl,
                width: warped.width,
                height: warped.height,
              }
            : p
        )
      );
    } catch (err) {
      onNotify('error', 'Perspective correction failed', (err as Error).message);
    } finally {
      setWarping(false);
    }
  };

  const handleAutoDetect = async () => {
    if (!activePage) return;
    setWarping(true);
    try {
      const corners = await detectDocumentCorners(activePage.rawDataUrl);
      const updated = { ...activePage, corners };
      await applyPerspectiveAndFilter(updated);
    } finally {
      setWarping(false);
    }
  };

  const handleSavePdf = async () => {
    if (pages.length === 0) return;
    setExporting(true);
    try {
      const bytes = await imagesToPdf(
        pages.map((p, i) => ({
          id: p.id,
          name: `scan_${i + 1}.jpg`,
          originalDataUrl: p.rawDataUrl,
          processedDataUrl: p.processedDataUrl,
          rotation: 0,
          filter: p.filter,
          crop: { x: 0, y: 0, w: 1, h: 1 },
          width: p.width,
          height: p.height,
        })),
        { pageSize: 'A4', orientation: 'portrait', marginPt: 16 }
      );
      const finalName = outputName.toLowerCase().endsWith('.pdf')
        ? outputName
        : `${outputName}.pdf`;
      const saved = await onSaveFile({
        name: finalName,
        size: bytes.byteLength,
        pageCount: pages.length,
        category: 'created',
        mimeType: 'application/pdf',
        data: bytes,
        sourceTool: 'Camera Scanner',
      });
      setSavedFile(saved);
      onNotify('success', 'Scanned PDF saved', `${finalName} · ${pages.length} page(s)`);
    } catch (err) {
      onNotify('error', 'Export failed', (err as Error).message);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title="Camera Scanner"
        subtitle="Auto edge detection, perspective warp & document filters"
        onBack={onBack}
      />

      <div className="max-w-6xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-5">
          {/* Capture Bar */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => setShowCamera(true)}
              className="flex-1 min-w-[160px] min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700"
            >
              <Camera className="w-4 h-4" />
              <span>Scan with Camera</span>
            </button>
            <label className="min-h-[44px] px-4 flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm font-semibold text-slate-800 dark:text-slate-100 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
              <Upload className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Import Photo</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={handleFileUpload} />
            </label>
          </div>

          {!activePage ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 bg-white/60 dark:bg-slate-900/40 py-16 px-6 text-center">
              <ScanLine className="w-12 h-12 text-blue-600/70 dark:text-blue-400/70 mx-auto" />
              <h3 className="mt-3 text-base font-bold text-slate-900 dark:text-white">
                Ready to scan documents
              </h3>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                Capture receipts, IDs, contracts, or notes. Drag the 4 corner handles to straighten perspective and apply crisp B&W, Color, or Grayscale filters.
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Drag the 4 blue corner handles for manual perspective crop
                </p>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleAutoDetect}
                    disabled={warping}
                    className="min-h-[38px] px-3 flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    <span>Auto Detect</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPerspectiveAndFilter(activePage)}
                    disabled={warping}
                    className="min-h-[38px] px-3.5 flex items-center gap-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700"
                  >
                    {warping ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>Apply Crop</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Raw Image with 4-corner SVG overlay */}
                <div className="space-y-1.5">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    Original & Corner Crop
                  </p>
                  <div
                    ref={stageRef}
                    onPointerMove={handleCornerPointerMove}
                    onPointerUp={() => setDraggingCorner(null)}
                    onPointerLeave={() => setDraggingCorner(null)}
                    className="relative select-none touch-none rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center"
                  >
                    <img
                      src={activePage.rawDataUrl}
                      alt="Raw scan"
                      className="w-full h-auto block pointer-events-none"
                    />
                    <svg
                      viewBox="0 0 100 100"
                      preserveAspectRatio="none"
                      className="absolute inset-0 w-full h-full pointer-events-none"
                    >
                      <polygon
                        points={activePage.corners
                          .map((c) => `${c.x * 100},${c.y * 100}`)
                          .join(' ')}
                        fill="rgba(37, 99, 235, 0.16)"
                        stroke="#2563EB"
                        strokeWidth="0.9"
                      />
                    </svg>
                    {activePage.corners.map((c, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onPointerDown={(e) => {
                          e.currentTarget.setPointerCapture(e.pointerId);
                          setDraggingCorner(idx);
                        }}
                        style={{
                          left: `${c.x * 100}%`,
                          top: `${c.y * 100}%`,
                        }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-blue-600 border-2 border-white shadow-md cursor-grab active:cursor-grabbing"
                        aria-label={`Corner ${idx + 1}`}
                      />
                    ))}
                  </div>
                </div>

                {/* Warped & Filtered Preview */}
                <div className="space-y-1.5">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    Corrected Result ({activePage.filter})
                  </p>
                  <div className="rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-center min-h-[200px] p-2">
                    <img
                      src={activePage.processedDataUrl}
                      alt="Corrected scan"
                      className="max-h-[340px] w-auto object-contain rounded shadow"
                    />
                  </div>
                </div>
              </div>

              {/* Filter Selector */}
              <div className="grid grid-cols-4 gap-2 pt-2">
                {(
                  [
                    { id: 'bw', label: 'Black & White' },
                    { id: 'enhance', label: 'Color Enhance' },
                    { id: 'grayscale', label: 'Grayscale' },
                    { id: 'original', label: 'Original' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    disabled={warping}
                    onClick={() => applyPerspectiveAndFilter(activePage, f.id)}
                    className={`min-h-[42px] rounded-xl text-xs font-semibold border transition-colors ${
                      activePage.filter === f.id
                        ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Multi-page Scan Queue & Save */}
        <div className="lg:col-span-4 space-y-4">
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Scanned Pages ({pages.length})
              </h2>
            </div>

            {pages.length > 0 && (
              <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto pr-1">
                {pages.map((p, idx) => (
                  <div
                    key={p.id}
                    className={`relative rounded-xl border overflow-hidden cursor-pointer ${
                      activePage?.id === p.id
                        ? 'border-blue-600 ring-2 ring-blue-600/20'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                    onClick={() => setActiveId(p.id)}
                  >
                    <img
                      src={p.processedDataUrl}
                      alt={`Scan ${idx + 1}`}
                      className="w-full aspect-[3/4] object-cover"
                    />
                    <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-slate-950/70 text-[10px] font-mono-nums text-white">
                      {idx + 1}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setPages((prev) => prev.filter((item) => item.id !== p.id));
                      }}
                      className="absolute top-1 right-1 w-6 h-6 rounded-lg bg-slate-950/70 text-white flex items-center justify-center hover:bg-rose-600"
                      aria-label="Delete page"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                PDF File Name
              </label>
              <input
                type="text"
                value={outputName}
                onChange={(e) => setOutputName(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-white focus:border-blue-600 focus:outline-none"
              />
            </div>

            <button
              type="button"
              disabled={pages.length === 0 || exporting || warping}
              onClick={handleSavePdf}
              className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
            >
              {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FilePlus2 className="w-4 h-4" />}
              <span>Save as PDF</span>
            </button>
          </div>

          {savedFile && (
            <div className="rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 space-y-3">
              <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                Scan Saved
              </p>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono-nums">
                {savedFile.name} · {formatBytes(savedFile.size)}
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onOpenViewer(savedFile)}
                  className="flex-1 min-h-[40px] rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-200"
                >
                  Open
                </button>
                <button
                  type="button"
                  onClick={() => saveBytesToDevice(savedFile.data, savedFile.name)}
                  className="flex-1 min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 text-xs font-semibold text-white"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Save to Device</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showCamera && (
        <CameraModal
          title="Scan Document"
          onClose={() => setShowCamera(false)}
          onCapture={async (url) => {
            setShowCamera(false);
            await ingestImage(url);
          }}
        />
      )}
    </div>
  );
};
