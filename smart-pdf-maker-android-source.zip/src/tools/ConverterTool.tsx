import React, { useState } from 'react';
import {
  Download,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  Image as ImageIcon,
  Loader2,
  Presentation,
  RefreshCw,
  Upload,
} from 'lucide-react';
import { AppSettings, StoredFile } from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  bundleImagesAsZip,
  excelToPdf,
  getPdfPageCount,
  pdfToImages,
  pdfToWord,
  pptToPdf,
  wordToPdf,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { StoredFilePickerModal } from '../components/StoredFilePickerModal';
import { PasswordPromptModal } from '../components/PasswordPromptModal';

export type ConverterMode =
  | 'pdf-to-image'
  | 'word-to-pdf'
  | 'excel-to-pdf'
  | 'ppt-to-pdf'
  | 'pdf-to-word';

interface ConverterToolProps {
  mode: ConverterMode;
  settings: AppSettings;
  storedFiles: StoredFile[];
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

const MODE_META: Record<
  ConverterMode,
  {
    title: string;
    subtitle: string;
    accept: string;
    pickLabel: string;
    isPdfInput: boolean;
  }
> = {
  'pdf-to-image': {
    title: 'PDF to Image',
    subtitle: 'Export PDF pages to high-resolution JPG or PNG images',
    accept: 'application/pdf,.pdf',
    pickLabel: 'Select PDF File',
    isPdfInput: true,
  },
  'word-to-pdf': {
    title: 'Word to PDF',
    subtitle: 'Convert .docx Word documents into clean PDF pages',
    accept: '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    pickLabel: 'Select Word (.docx) File',
    isPdfInput: false,
  },
  'excel-to-pdf': {
    title: 'Excel to PDF',
    subtitle: 'Convert .xlsx, .xls, and .csv spreadsheets to PDF tables',
    accept: '.xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv',
    pickLabel: 'Select Spreadsheet (.xlsx / .csv)',
    isPdfInput: false,
  },
  'ppt-to-pdf': {
    title: 'PPT to PDF',
    subtitle: 'Convert .pptx PowerPoint presentations to 16:9 PDF slides',
    accept: '.pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation',
    pickLabel: 'Select PowerPoint (.pptx)',
    isPdfInput: false,
  },
  'pdf-to-word': {
    title: 'PDF to Word',
    subtitle: 'Extract PDF document content into an editable .docx file',
    accept: 'application/pdf,.pdf',
    pickLabel: 'Select PDF File',
    isPdfInput: true,
  },
};

export const ConverterTool: React.FC<ConverterToolProps> = ({
  mode: initialMode,
  settings,
  storedFiles,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [mode, setMode] = useState<ConverterMode>(initialMode);
  const [sourceFile, setSourceFile] = useState<{ name: string; bytes: Uint8Array } | null>(null);
  const [password, setPassword] = useState<string | undefined>(undefined);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | undefined>(undefined);

  const [imgFormat, setImgFormat] = useState<'jpeg' | 'png'>('jpeg');
  const [imgScale, setImgScale] = useState<number>(2);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showPicker, setShowPicker] = useState(false);

  const [exportedImages, setExportedImages] = useState<
    Array<{ name: string; blob: Blob; dataUrl: string }>
  >([]);
  const [outputPdf, setOutputPdf] = useState<StoredFile | null>(null);
  const [outputDocx, setOutputDocx] = useState<{
    name: string;
    bytes: Uint8Array;
    extractedText: string;
  } | null>(null);
  const [excelPreview, setExcelPreview] = useState<string[][]>([]);

  const meta = MODE_META[mode];

  const resetOutputs = () => {
    setExportedImages([]);
    setOutputPdf(null);
    setOutputDocx(null);
    setExcelPreview([]);
  };

  const selectPdfSource = async (bytes: Uint8Array, name: string, pw?: string) => {
    setSourceFile({ name, bytes });
    resetOutputs();
    try {
      await getPdfPageCount(bytes, pw);
      setPassword(pw);
      setNeedsPassword(false);
      setPasswordError(undefined);
    } catch (err) {
      if (err instanceof PasswordRequiredError) {
        setNeedsPassword(true);
        setPasswordError(undefined);
      } else if (err instanceof IncorrectPasswordError) {
        setNeedsPassword(true);
        setPasswordError('Incorrect password. Please try again.');
      } else {
        onNotify('error', 'Failed to read PDF', (err as Error).message);
      }
    }
  };

  const handleFileInput = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (meta.isPdfInput) {
      await selectPdfSource(bytes, file.name);
    } else {
      setSourceFile({ name: file.name, bytes });
      resetOutputs();
    }
    e.target.value = '';
  };

  const handleConvert = async () => {
    if (!sourceFile) return;
    setProcessing(true);
    setProgress(5);
    resetOutputs();

    try {
      const baseName = sourceFile.name.replace(/\.[^.]+$/, '');
      const buf = sourceFile.bytes.buffer.slice(
        sourceFile.bytes.byteOffset,
        sourceFile.bytes.byteOffset + sourceFile.bytes.byteLength
      ) as ArrayBuffer;

      if (mode === 'pdf-to-image') {
        const imgs = await pdfToImages(sourceFile.bytes, imgFormat, imgScale, password, setProgress);
        setExportedImages(imgs);
        onNotify('success', `Converted ${imgs.length} page(s) to ${imgFormat.toUpperCase()}`);
      } else if (mode === 'word-to-pdf') {
        const res = await wordToPdf(
          buf,
          settings.defaultPageSize,
          settings.defaultOrientation,
          setProgress
        );
        const info = await getPdfPageCount(res.bytes);
        const saved = await onSaveFile({
          name: `${baseName}.pdf`,
          size: res.bytes.byteLength,
          pageCount: info.pageCount,
          category: 'created',
          mimeType: 'application/pdf',
          data: res.bytes,
          sourceTool: 'Word to PDF',
        });
        setOutputPdf(saved);
        onNotify('success', 'Word converted to PDF', `${saved.name} · ${info.pageCount} page(s)`);
      } else if (mode === 'excel-to-pdf') {
        const res = await excelToPdf(buf, settings.defaultPageSize, 'landscape', setProgress);
        setExcelPreview(res.previewRows);
        const info = await getPdfPageCount(res.bytes);
        const saved = await onSaveFile({
          name: `${baseName}.pdf`,
          size: res.bytes.byteLength,
          pageCount: info.pageCount,
          category: 'created',
          mimeType: 'application/pdf',
          data: res.bytes,
          sourceTool: 'Excel to PDF',
        });
        setOutputPdf(saved);
        onNotify('success', 'Spreadsheet converted to PDF', `${res.sheetNames.length} sheet(s)`);
      } else if (mode === 'ppt-to-pdf') {
        const res = await pptToPdf(buf, setProgress);
        const saved = await onSaveFile({
          name: `${baseName}.pdf`,
          size: res.bytes.byteLength,
          pageCount: Math.max(1, res.slideCount),
          category: 'created',
          mimeType: 'application/pdf',
          data: res.bytes,
          sourceTool: 'PPT to PDF',
        });
        setOutputPdf(saved);
        onNotify('success', 'Presentation converted to PDF', `${res.slideCount} slide(s)`);
      } else if (mode === 'pdf-to-word') {
        const res = await pdfToWord(sourceFile.bytes, sourceFile.name, password, setProgress);
        const docxBytes = new Uint8Array(await res.blob.arrayBuffer());
        const outName = `${baseName}.docx`;
        await onSaveFile({
          name: outName,
          size: docxBytes.byteLength,
          pageCount: 1,
          category: 'created',
          mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          data: docxBytes,
          sourceTool: 'PDF to Word',
        });
        setOutputDocx({ name: outName, bytes: docxBytes, extractedText: res.extractedText });
        onNotify('success', 'Converted to Word (.docx)', outName);
      }
    } catch (err) {
      onNotify('error', 'Conversion failed', (err as Error).message);
    } finally {
      setProcessing(false);
    }
  };

  const handleDownloadZip = async () => {
    if (exportedImages.length === 0) return;
    const zipBytes = await bundleImagesAsZip(exportedImages);
    const baseName = (sourceFile?.name || 'pages').replace(/\.pdf$/i, '');
    await saveBytesToDevice(zipBytes, `${baseName}_images.zip`, 'application/zip');
    onNotify('success', 'ZIP archive saved');
  };

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader title={meta.title} subtitle={meta.subtitle} onBack={onBack} />

      {needsPassword && sourceFile && (
        <PasswordPromptModal
          fileName={sourceFile.name}
          errorMessage={passwordError}
          onSubmit={(pw) => selectPdfSource(sourceFile.bytes, sourceFile.name, pw)}
          onCancel={() => {
            setNeedsPassword(false);
            setSourceFile(null);
          }}
        />
      )}

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-5">
        {/* Converter Mode Switcher */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(
            [
              { id: 'pdf-to-image', label: 'PDF to Image', icon: ImageIcon },
              { id: 'word-to-pdf', label: 'Word to PDF', icon: FileText },
              { id: 'excel-to-pdf', label: 'Excel to PDF', icon: FileSpreadsheet },
              { id: 'ppt-to-pdf', label: 'PPT to PDF', icon: Presentation },
              { id: 'pdf-to-word', label: 'PDF to Word', icon: RefreshCw },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            const active = mode === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setMode(item.id);
                  setSourceFile(null);
                  resetOutputs();
                }}
                className={`min-h-[40px] px-3.5 flex items-center gap-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 border transition-colors ${
                  active
                    ? 'border-blue-600 bg-blue-600 text-white'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* File Picker Card */}
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <label className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
              <Upload className="w-4 h-4" />
              <span>{meta.pickLabel}</span>
              <input type="file" accept={meta.accept} className="hidden" onChange={handleFileInput} />
            </label>
            {meta.isPdfInput && (
              <button
                type="button"
                onClick={() => setShowPicker(true)}
                className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-4 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <FolderOpen className="w-4 h-4 text-blue-600" />
                <span>Choose from My Files</span>
              </button>
            )}
          </div>

          {sourceFile && (
            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {sourceFile.name}
                </p>
                <p className="text-xs text-slate-500 font-mono-nums">
                  {formatBytes(sourceFile.bytes.byteLength)}
                </p>
              </div>
            </div>
          )}

          {mode === 'pdf-to-image' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                  Output Image Format
                </label>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
                  {(['jpeg', 'png'] as const).map((fmt) => (
                    <button
                      key={fmt}
                      type="button"
                      onClick={() => setImgFormat(fmt)}
                      className={`min-h-[38px] rounded-lg text-xs font-bold uppercase ${
                        imgFormat === fmt
                          ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {fmt === 'jpeg' ? 'JPG' : 'PNG'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                  Resolution Quality
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl">
                  {[
                    { val: 1, label: 'Standard' },
                    { val: 2, label: 'High (2x)' },
                    { val: 3, label: 'Ultra (3x)' },
                  ].map((q) => (
                    <button
                      key={q.val}
                      type="button"
                      onClick={() => setImgScale(q.val)}
                      className={`min-h-[38px] rounded-lg text-xs font-semibold ${
                        imgScale === q.val
                          ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {processing && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium text-slate-600 dark:text-slate-300">
                <span>Converting document...</span>
                <span className="font-mono-nums">{progress}%</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div className="h-full bg-blue-600 transition-all" style={{ width: `${progress}%` }} />
              </div>
            </div>
          )}

          <button
            type="button"
            disabled={!sourceFile || processing}
            onClick={handleConvert}
            className="w-full min-h-[48px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
          >
            {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>Convert Now</span>
          </button>
        </div>

        {/* Output: PDF */}
        {outputPdf && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 p-5 space-y-4">
            <div>
              <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                Conversion Complete: {outputPdf.name}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-nums">
                {formatBytes(outputPdf.size)} · {outputPdf.pageCount} page(s)
              </p>
            </div>
            {excelPreview.length > 0 && (
              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-xs text-left">
                  <tbody>
                    {excelPreview.slice(0, 5).map((row, rIdx) => (
                      <tr
                        key={rIdx}
                        className={rIdx === 0 ? 'bg-blue-50 dark:bg-blue-950/40 font-semibold' : 'border-t border-slate-100 dark:border-slate-800'}
                      >
                        {row.slice(0, 6).map((cell, cIdx) => (
                          <td key={cIdx} className="px-2.5 py-1.5 truncate max-w-[140px]">
                            {String(cell ?? '')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => onOpenViewer(outputPdf)}
                className="flex-1 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold"
              >
                Open PDF
              </button>
              <button
                type="button"
                onClick={() => saveBytesToDevice(outputPdf.data, outputPdf.name)}
                className="flex-1 min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white"
              >
                <Download className="w-4 h-4" />
                <span>Save PDF</span>
              </button>
            </div>
          </div>
        )}

        {/* Output: Word DOCX */}
        {outputDocx && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">{outputDocx.name}</p>
                <p className="text-xs text-slate-500 font-mono-nums">
                  {formatBytes(outputDocx.bytes.byteLength)}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  saveBytesToDevice(
                    outputDocx.bytes,
                    outputDocx.name,
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
                  )
                }
                className="min-h-[42px] px-4 flex items-center gap-2 rounded-xl bg-blue-600 text-xs font-semibold text-white"
              >
                <Download className="w-4 h-4" />
                <span>Save .docx</span>
              </button>
            </div>
            {outputDocx.extractedText && (
              <pre className="max-h-52 overflow-y-auto rounded-xl bg-slate-50 dark:bg-slate-950 p-3 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap font-sans">
                {outputDocx.extractedText.slice(0, 1500)}
              </pre>
            )}
          </div>
        )}

        {/* Output: Images */}
        {exportedImages.length > 0 && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-bold text-slate-900 dark:text-white">
                {exportedImages.length} Exported Image(s)
              </p>
              <button
                type="button"
                onClick={handleDownloadZip}
                className="min-h-[40px] px-4 flex items-center gap-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download All (.zip)</span>
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {exportedImages.map((img) => (
                <div
                  key={img.name}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50 dark:bg-slate-950"
                >
                  <img src={img.dataUrl} alt={img.name} className="w-full aspect-[3/4] object-contain" />
                  <div className="p-2 flex items-center justify-between gap-2 bg-white dark:bg-slate-900">
                    <span className="text-xs font-mono-nums truncate">{img.name}</span>
                    <button
                      type="button"
                      onClick={async () => {
                        const arr = new Uint8Array(await img.blob.arrayBuffer());
                        await saveBytesToDevice(
                          arr,
                          img.name,
                          imgFormat === 'jpeg' ? 'image/jpeg' : 'image/png'
                        );
                      }}
                      className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950 text-xs font-semibold text-blue-600 dark:text-blue-400"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {showPicker && (
        <StoredFilePickerModal
          files={storedFiles}
          onClose={() => setShowPicker(false)}
          onSelect={(f) => {
            setShowPicker(false);
            selectPdfSource(f.data, f.name);
          }}
        />
      )}
    </div>
  );
};
