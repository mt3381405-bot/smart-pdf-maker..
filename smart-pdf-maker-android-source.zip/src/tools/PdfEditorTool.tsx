import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Download,
  FileText,
  FolderOpen,
  Highlighter,
  ImagePlus,
  Loader2,
  MousePointer,
  PenTool,
  Pencil,
  RotateCw,
  Save,
  Trash2,
  Type,
  Undo2,
  Upload,
  X,
} from 'lucide-react';
import {
  EditorPageState,
  EditorToolMode,
  PdfAnnotation,
  Point2D,
  StoredFile,
} from '../types';
import {
  IncorrectPasswordError,
  PasswordRequiredError,
  readFileAsDataUrl,
  renderAllPdfThumbnails,
  renderPdfPageToDataUrl,
  saveEditedPdf,
} from '../services/pdfEngine';
import { formatBytes, saveBytesToDevice } from '../services/fileStorage';
import { ToolHeader } from '../components/ToolHeader';
import { StoredFilePickerModal } from '../components/StoredFilePickerModal';
import { PasswordPromptModal } from '../components/PasswordPromptModal';

interface PdfEditorToolProps {
  initialMode?: EditorToolMode;
  initialFile?: { file: StoredFile; password?: string } | null;
  storedFiles: StoredFile[];
  onBack: () => void;
  onSaveFile: (file: Omit<StoredFile, 'id' | 'createdAt' | 'lastOpenedAt'>) => Promise<StoredFile>;
  onNotify: (type: 'success' | 'error' | 'info', title: string, description?: string) => void;
  onOpenViewer: (file: StoredFile) => void;
}

export const PdfEditorTool: React.FC<PdfEditorToolProps> = ({
  initialMode = 'select',
  initialFile,
  storedFiles,
  onBack,
  onSaveFile,
  onNotify,
  onOpenViewer,
}) => {
  const [sourceBytes, setSourceBytes] = useState<Uint8Array | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [password, setPassword] = useState<string | undefined>(undefined);
  const [needsPassword, setNeedsPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | undefined>(undefined);

  const [pages, setPages] = useState<EditorPageState[]>([]);
  const [activePageIndex, setActivePageIndex] = useState(0);
  const [activePageImg, setActivePageImg] = useState<string>('');
  const [loadingPdf, setLoadingPdf] = useState(false);

  const [toolMode, setToolMode] = useState<EditorToolMode>(initialMode);
  const [color, setColor] = useState(initialMode === 'highlight' ? '#FACC15' : '#2563EB');
  const [fontSize, setFontSize] = useState(16);
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [pendingText, setPendingText] = useState('Approved');
  const [pendingImageUrl, setPendingImageUrl] = useState<string | null>(null);
  const [showSignaturePad, setShowSignaturePad] = useState(false);

  const [annotations, setAnnotations] = useState<PdfAnnotation[]>([]);
  const [draftPoints, setDraftPoints] = useState<Point2D[]>([]);
  const [dragHighlight, setDragHighlight] = useState<{
    startX: number;
    startY: number;
    endX: number;
    endY: number;
  } | null>(null);

  const [showPicker, setShowPicker] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedFile, setSavedFile] = useState<StoredFile | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);

  const loadPdfBytes = async (bytes: Uint8Array, name: string, pw?: string) => {
    setLoadingPdf(true);
    setSourceBytes(bytes);
    setFileName(name);
    setSavedFile(null);
    try {
      const thumbs = await renderAllPdfThumbnails(bytes, 0.35, pw);
      setPages(
        thumbs.map((t, idx) => ({
          id: `pg_${idx}_${Date.now()}`,
          originalIndex: idx,
          rotation: 0,
          thumbnailUrl: t.dataUrl,
          width: t.width,
          height: t.height,
        }))
      );
      setAnnotations([]);
      setActivePageIndex(0);
      setPassword(pw);
      setNeedsPassword(false);
      setPasswordError(undefined);
      if (initialMode === 'signature') {
        setShowSignaturePad(true);
      }
    } catch (err) {
      if (err instanceof PasswordRequiredError) {
        setNeedsPassword(true);
        setPasswordError(undefined);
      } else if (err instanceof IncorrectPasswordError) {
        setNeedsPassword(true);
        setPasswordError('Incorrect password. Please try again.');
      } else {
        onNotify('error', 'Could not open PDF', (err as Error).message);
      }
    } finally {
      setLoadingPdf(false);
    }
  };

  useEffect(() => {
    if (initialFile) {
      loadPdfBytes(initialFile.file.data, initialFile.file.name, initialFile.password);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialFile]);

  const currentPageState = pages[activePageIndex] || null;

  useEffect(() => {
    let cancelled = false;
    async function renderActive() {
      if (!sourceBytes || !currentPageState) {
        setActivePageImg('');
        return;
      }
      try {
        const res = await renderPdfPageToDataUrl(
          sourceBytes,
          currentPageState.originalIndex,
          1.6,
          password
        );
        if (!cancelled) setActivePageImg(res.dataUrl);
      } catch {
        // ignore transient render error
      }
    }
    renderActive();
    return () => {
      cancelled = true;
    };
  }, [sourceBytes, currentPageState, password]);

  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = new Uint8Array(await file.arrayBuffer());
    await loadPdfBytes(buf, file.name);
    e.target.value = '';
  };

  const handlePickAnnotImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await readFileAsDataUrl(file);
    setPendingImageUrl(url);
    setToolMode('image');
    onNotify('info', 'Tap anywhere on the page to place the image');
    e.target.value = '';
  };

  const getNormCoords = (e: React.PointerEvent<HTMLDivElement>): Point2D => {
    const rect = stageRef.current!.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)),
      y: Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!currentPageState || !stageRef.current) return;
    const pt = getNormCoords(e);

    if (toolMode === 'text') {
      if (!pendingText.trim()) return;
      setAnnotations((prev) => [
        ...prev,
        {
          id: `ann_${Date.now()}`,
          pageIndex: currentPageState.originalIndex,
          type: 'text',
          x: pt.x,
          y: pt.y,
          text: pendingText.trim(),
          fontSize,
          color,
        },
      ]);
      return;
    }

    if ((toolMode === 'image' || toolMode === 'signature') && pendingImageUrl) {
      const boxW = toolMode === 'signature' ? 0.28 : 0.3;
      const boxH = toolMode === 'signature' ? 0.11 : 0.22;
      setAnnotations((prev) => [
        ...prev,
        {
          id: `ann_${Date.now()}`,
          pageIndex: currentPageState.originalIndex,
          type: toolMode,
          x: Math.max(0, Math.min(1 - boxW, pt.x - boxW / 2)),
          y: Math.max(0, Math.min(1 - boxH, pt.y - boxH / 2)),
          width: boxW,
          height: boxH,
          imageDataUrl: pendingImageUrl,
        },
      ]);
      return;
    }

    if (toolMode === 'draw') {
      e.currentTarget.setPointerCapture(e.pointerId);
      setDraftPoints([pt]);
    } else if (toolMode === 'highlight') {
      e.currentTarget.setPointerCapture(e.pointerId);
      setDragHighlight({ startX: pt.x, startY: pt.y, endX: pt.x, endY: pt.y });
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!stageRef.current) return;
    const pt = getNormCoords(e);
    if (toolMode === 'draw' && draftPoints.length > 0) {
      setDraftPoints((prev) => [...prev, pt]);
    } else if (toolMode === 'highlight' && dragHighlight) {
      setDragHighlight((prev) => (prev ? { ...prev, endX: pt.x, endY: pt.y } : null));
    }
  };

  const handlePointerUp = () => {
    if (!currentPageState) return;
    if (toolMode === 'draw' && draftPoints.length > 1) {
      setAnnotations((prev) => [
        ...prev,
        {
          id: `ann_${Date.now()}`,
          pageIndex: currentPageState.originalIndex,
          type: 'draw',
          x: 0,
          y: 0,
          points: draftPoints,
          color,
          strokeWidth,
        },
      ]);
    } else if (toolMode === 'highlight' && dragHighlight) {
      const x = Math.min(dragHighlight.startX, dragHighlight.endX);
      const y = Math.min(dragHighlight.startY, dragHighlight.endY);
      const w = Math.abs(dragHighlight.endX - dragHighlight.startX);
      const h = Math.abs(dragHighlight.endY - dragHighlight.startY);
      if (w > 0.02 && h > 0.01) {
        setAnnotations((prev) => [
          ...prev,
          {
            id: `ann_${Date.now()}`,
            pageIndex: currentPageState.originalIndex,
            type: 'highlight',
            x,
            y,
            width: w,
            height: h,
            color,
          },
        ]);
      }
    }
    setDraftPoints([]);
    setDragHighlight(null);
  };

  const rotateActivePage = () => {
    setPages((prev) =>
      prev.map((p, i) =>
        i === activePageIndex ? { ...p, rotation: (p.rotation + 90) % 360 } : p
      )
    );
  };

  const deletePage = (idx: number) => {
    if (pages.length <= 1) {
      onNotify('error', 'Cannot delete the last page');
      return;
    }
    setPages((prev) => prev.filter((_, i) => i !== idx));
    setActivePageIndex((prevIdx) => Math.max(0, Math.min(prevIdx, pages.length - 2)));
  };

  const movePage = (idx: number, delta: number) => {
    const target = idx + delta;
    if (target < 0 || target >= pages.length) return;
    setPages((prev) => {
      const next = [...prev];
      [next[idx], next[target]] = [next[target], next[idx]];
      return next;
    });
    if (activePageIndex === idx) setActivePageIndex(target);
  };

  const undoAnnotation = () => {
    if (!currentPageState) return;
    const revIdx = [...annotations]
      .reverse()
      .findIndex((a) => a.pageIndex === currentPageState.originalIndex);
    if (revIdx === -1) return;
    const realIdx = annotations.length - 1 - revIdx;
    setAnnotations((prev) => prev.filter((_, i) => i !== realIdx));
  };

  const handleSavePdf = async () => {
    if (!sourceBytes || pages.length === 0) return;
    setSaving(true);
    try {
      const bytes = await saveEditedPdf(sourceBytes, pages, annotations, password);
      const outName = fileName.replace(/\.pdf$/i, '') + '_edited.pdf';
      const saved = await onSaveFile({
        name: outName,
        size: bytes.byteLength,
        pageCount: pages.length,
        category: 'created',
        mimeType: 'application/pdf',
        data: bytes,
        sourceTool: initialMode === 'signature' ? 'PDF Signature' : 'PDF Editor',
      });
      setSavedFile(saved);
      onNotify('success', 'Edited PDF saved', `${outName} · ${formatBytes(bytes.byteLength)}`);
    } catch (err) {
      onNotify('error', 'Failed to save PDF', (err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const activeAnnots = currentPageState
    ? annotations.filter((a) => a.pageIndex === currentPageState.originalIndex)
    : [];

  return (
    <div className="min-h-screen pb-24 lg:pb-10">
      <ToolHeader
        title={initialMode === 'signature' ? 'PDF Signature' : 'PDF Editor'}
        subtitle="Annotate, draw, highlight, sign, rotate & organize pages"
        onBack={onBack}
        rightSlot={
          pages.length > 0 ? (
            <button
              type="button"
              disabled={saving}
              onClick={handleSavePdf}
              className="min-h-[38px] px-3.5 flex items-center gap-1.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>Save PDF</span>
            </button>
          ) : null
        }
      />

      {needsPassword && sourceBytes && (
        <PasswordPromptModal
          fileName={fileName}
          errorMessage={passwordError}
          onSubmit={(pw) => loadPdfBytes(sourceBytes, fileName, pw)}
          onCancel={() => {
            setNeedsPassword(false);
            setSourceBytes(null);
            setPages([]);
          }}
        />
      )}

      <div className="max-w-7xl mx-auto px-4 py-5 space-y-5">
        {pages.length === 0 ? (
          <div className="max-w-xl mx-auto rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center space-y-5 mt-6">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
              {loadingPdf ? <Loader2 className="w-7 h-7 animate-spin" /> : <FileText className="w-7 h-7" />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {initialMode === 'signature' ? 'Open a PDF to Sign' : 'Open a PDF to Edit'}
              </h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Select a PDF from your device or open one from My Files. All edits are processed locally.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <label className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white cursor-pointer hover:bg-blue-700">
                <Upload className="w-4 h-4" />
                <span>Choose from Device</span>
                <input type="file" accept="application/pdf,.pdf" className="hidden" onChange={handleUploadFile} />
              </label>
              <button
                type="button"
                onClick={() => setShowPicker(true)}
                className="flex-1 min-h-[46px] flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 px-4 text-sm font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                <FolderOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>My Files</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Page Thumbnails Sidebar */}
            <aside className="lg:col-span-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-3.5 space-y-3 max-h-[75vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-700 dark:text-slate-200">
                  Pages ({pages.length})
                </h3>
                <button
                  type="button"
                  onClick={() => setShowPicker(true)}
                  className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Switch PDF
                </button>
              </div>
              <div className="grid grid-cols-3 lg:grid-cols-1 gap-2.5">
                {pages.map((p, idx) => (
                  <div
                    key={p.id}
                    onClick={() => setActivePageIndex(idx)}
                    className={`rounded-xl border p-2 cursor-pointer transition-all ${
                      idx === activePageIndex
                        ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/30'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div className="aspect-[3/4] bg-slate-100 dark:bg-slate-950 rounded-lg overflow-hidden flex items-center justify-center">
                      <img
                        src={p.thumbnailUrl}
                        alt={`Page ${idx + 1}`}
                        style={{ transform: `rotate(${p.rotation}deg)` }}
                        className="max-h-full max-w-full object-contain transition-transform"
                      />
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-1">
                      <span className="text-xs font-mono-nums font-semibold text-slate-700 dark:text-slate-300">
                        #{idx + 1}
                      </span>
                      <div className="flex items-center gap-0.5">
                        <button
                          type="button"
                          disabled={idx === 0}
                          onClick={(e) => {
                            e.stopPropagation();
                            movePage(idx, -1);
                          }}
                          className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-30"
                          aria-label="Move page up"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={idx === pages.length - 1}
                          onClick={(e) => {
                            e.stopPropagation();
                            movePage(idx, 1);
                          }}
                          className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-30"
                          aria-label="Move page down"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            deletePage(idx);
                          }}
                          className="p-1 rounded text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50"
                          aria-label="Delete page"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </aside>

            {/* Main Editor Workspace */}
            <div className="lg:col-span-9 space-y-4">
              {/* Toolbar */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-3 space-y-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  {(
                    [
                      { id: 'select', label: 'View', icon: MousePointer },
                      { id: 'text', label: 'Text', icon: Type },
                      { id: 'highlight', label: 'Highlight', icon: Highlighter },
                      { id: 'draw', label: 'Draw', icon: Pencil },
                      { id: 'signature', label: 'Sign', icon: PenTool },
                    ] as const
                  ).map((tool) => {
                    const Icon = tool.icon;
                    const active = toolMode === tool.id;
                    return (
                      <button
                        key={tool.id}
                        type="button"
                        onClick={() => {
                          setToolMode(tool.id);
                          if (tool.id === 'highlight') setColor('#FACC15');
                          if (tool.id === 'draw' && color === '#FACC15') setColor('#2563EB');
                          if (tool.id === 'signature') setShowSignaturePad(true);
                        }}
                        className={`min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl text-xs font-semibold transition-colors ${
                          active
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{tool.label}</span>
                      </button>
                    );
                  })}

                  <label className="min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer">
                    <ImagePlus className="w-3.5 h-3.5" />
                    <span>Image</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handlePickAnnotImage} />
                  </label>

                  <button
                    type="button"
                    onClick={rotateActivePage}
                    className="min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Rotate</span>
                  </button>

                  <button
                    type="button"
                    onClick={undoAnnotation}
                    className="min-h-[40px] px-3 flex items-center gap-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
                  >
                    <Undo2 className="w-3.5 h-3.5" />
                    <span>Undo</span>
                  </button>
                </div>

                {/* Contextual Controls */}
                {(toolMode === 'text' || toolMode === 'draw' || toolMode === 'highlight') && (
                  <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                    {toolMode === 'text' && (
                      <>
                        <input
                          type="text"
                          value={pendingText}
                          onChange={(e) => setPendingText(e.target.value)}
                          placeholder="Text to place (tap page)"
                          className="flex-1 min-w-[180px] min-h-[38px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 text-xs"
                        />
                        <select
                          value={fontSize}
                          onChange={(e) => setFontSize(Number(e.target.value))}
                          className="min-h-[38px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-2.5 text-xs"
                        >
                          {[12, 16, 20, 26, 32].map((s) => (
                            <option key={s} value={s}>
                              {s}pt
                            </option>
                          ))}
                        </select>
                      </>
                    )}
                    {toolMode === 'draw' && (
                      <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                        <span>Thickness</span>
                        <input
                          type="range"
                          min={1}
                          max={8}
                          value={strokeWidth}
                          onChange={(e) => setStrokeWidth(Number(e.target.value))}
                          className="w-24 accent-blue-600"
                        />
                      </label>
                    )}
                    <div className="flex items-center gap-1.5">
                      {['#2563EB', '#0F172A', '#DC2626', '#16A34A', '#FACC15'].map((c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => setColor(c)}
                          style={{ backgroundColor: c }}
                          className={`w-6 h-6 rounded-full border-2 ${
                            color === c ? 'border-slate-900 dark:border-white scale-110' : 'border-transparent'
                          }`}
                          aria-label={`Color ${c}`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {toolMode === 'text'
                        ? 'Tap on the PDF page to add text'
                        : toolMode === 'highlight'
                        ? 'Drag across text to highlight'
                        : 'Draw freely on the page'}
                    </span>
                  </div>
                )}

                {(toolMode === 'image' || toolMode === 'signature') && pendingImageUrl && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-xs font-medium text-blue-600 dark:text-blue-400">
                      Tap on the PDF page to place your {toolMode}.
                    </span>
                    {toolMode === 'signature' && (
                      <button
                        type="button"
                        onClick={() => setShowSignaturePad(true)}
                        className="text-xs font-semibold text-slate-700 dark:text-slate-200 underline"
                      >
                        Redraw Signature
                      </button>
                    )}
                  </div>
                )}
              </div>

              {savedFile && (
                <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 p-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                      Saved {savedFile.name}
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 font-mono-nums">
                      {formatBytes(savedFile.size)} · {savedFile.pageCount} pages
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenViewer(savedFile)}
                      className="min-h-[40px] px-3.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-800 dark:text-emerald-200"
                    >
                      Open PDF
                    </button>
                    <button
                      type="button"
                      onClick={() => saveBytesToDevice(savedFile.data, savedFile.name)}
                      className="min-h-[40px] px-3.5 flex items-center gap-1.5 rounded-xl bg-emerald-600 text-xs font-semibold text-white"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Save to Device</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Page Canvas Stage */}
              <div className="rounded-2xl bg-slate-200/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 flex justify-center overflow-auto">
                <div
                  ref={stageRef}
                  onPointerDown={handlePointerDown}
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                  style={{
                    transform: currentPageState ? `rotate(${currentPageState.rotation}deg)` : undefined,
                  }}
                  className={`relative inline-block shadow-xl bg-white select-none ${
                    toolMode !== 'select' ? 'touch-none cursor-crosshair' : ''
                  }`}
                >
                  {activePageImg && (
                    <img
                      src={activePageImg}
                      alt={`Editing page ${activePageIndex + 1}`}
                      className="max-h-[70vh] w-auto block pointer-events-none"
                    />
                  )}

                  {/* SVG Drawing Layer */}
                  <svg
                    viewBox="0 0 100 100"
                    preserveAspectRatio="none"
                    className="absolute inset-0 w-full h-full pointer-events-none"
                  >
                    {activeAnnots
                      .filter((a) => a.type === 'highlight' && a.width && a.height)
                      .map((a) => (
                        <rect
                          key={a.id}
                          x={a.x * 100}
                          y={a.y * 100}
                          width={a.width! * 100}
                          height={a.height! * 100}
                          fill={a.color || '#FACC15'}
                          fillOpacity={0.38}
                        />
                      ))}

                    {dragHighlight && (
                      <rect
                        x={Math.min(dragHighlight.startX, dragHighlight.endX) * 100}
                        y={Math.min(dragHighlight.startY, dragHighlight.endY) * 100}
                        width={Math.abs(dragHighlight.endX - dragHighlight.startX) * 100}
                        height={Math.abs(dragHighlight.endY - dragHighlight.startY) * 100}
                        fill={color}
                        fillOpacity={0.35}
                      />
                    )}

                    {activeAnnots
                      .filter((a) => a.type === 'draw' && a.points && a.points.length > 1)
                      .map((a) => (
                        <polyline
                          key={a.id}
                          fill="none"
                          stroke={a.color || '#2563EB'}
                          strokeWidth={(a.strokeWidth || 3) * 0.25}
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          points={a.points!.map((pt) => `${pt.x * 100},${pt.y * 100}`).join(' ')}
                        />
                      ))}

                    {draftPoints.length > 1 && (
                      <polyline
                        fill="none"
                        stroke={color}
                        strokeWidth={strokeWidth * 0.25}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={draftPoints.map((pt) => `${pt.x * 100},${pt.y * 100}`).join(' ')}
                      />
                    )}
                  </svg>

                  {/* Text & Image Overlays */}
                  {activeAnnots
                    .filter((a) => a.type === 'text' && a.text)
                    .map((a) => (
                      <div
                        key={a.id}
                        style={{
                          left: `${a.x * 100}%`,
                          top: `${a.y * 100}%`,
                          color: a.color || '#0F172A',
                          fontSize: `${a.fontSize || 16}px`,
                        }}
                        className="absolute font-bold pointer-events-none whitespace-nowrap"
                      >
                        {a.text}
                      </div>
                    ))}

                  {activeAnnots
                    .filter((a) => (a.type === 'image' || a.type === 'signature') && a.imageDataUrl)
                    .map((a) => (
                      <img
                        key={a.id}
                        src={a.imageDataUrl}
                        alt={a.type}
                        style={{
                          left: `${a.x * 100}%`,
                          top: `${a.y * 100}%`,
                          width: `${(a.width || 0.25) * 100}%`,
                          height: `${(a.height || 0.12) * 100}%`,
                        }}
                        className="absolute object-contain pointer-events-none"
                      />
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {showPicker && (
        <StoredFilePickerModal
          files={storedFiles}
          onClose={() => setShowPicker(false)}
          onSelect={(f) => {
            setShowPicker(false);
            loadPdfBytes(f.data, f.name);
          }}
        />
      )}

      {showSignaturePad && (
        <SignaturePadModal
          onClose={() => setShowSignaturePad(false)}
          onSave={(sigDataUrl) => {
            setPendingImageUrl(sigDataUrl);
            setToolMode('signature');
            setShowSignaturePad(false);
            onNotify('info', 'Signature ready', 'Tap anywhere on the PDF page to place your signature.');
          }}
        />
      )}
    </div>
  );
};

const SignaturePadModal: React.FC<{
  onClose: () => void;
  onSave: (dataUrl: string) => void;
}> = ({ onClose, onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [drawing, setDrawing] = useState(false);
  const [inkColor, setInkColor] = useState('#0F172A');
  const [hasInk, setHasInk] = useState(false);

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvasRef.current!.width,
      y: ((e.clientY - rect.top) / rect.height) * canvasRef.current!.height,
    };
  };

  const handleDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const ctx = canvasRef.current!.getContext('2d')!;
    const { x, y } = getPos(e);
    ctx.strokeStyle = inkColor;
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(x, y);
    setDrawing(true);
    setHasInk(true);
  };

  const handleMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const ctx = canvasRef.current!.getContext('2d')!;
    const { x, y } = getPos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const clear = () => {
    const c = canvasRef.current!;
    c.getContext('2d')!.clearRect(0, 0, c.width, c.height);
    setHasInk(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Create Signature
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <canvas
          ref={canvasRef}
          width={560}
          height={220}
          onPointerDown={handleDown}
          onPointerMove={handleMove}
          onPointerUp={() => setDrawing(false)}
          className="w-full h-44 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 touch-none cursor-crosshair"
        />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {['#0F172A', '#1D4ED8', '#DC2626'].map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setInkColor(c)}
                style={{ backgroundColor: c }}
                className={`w-6 h-6 rounded-full border-2 ${
                  inkColor === c ? 'border-blue-500 scale-110' : 'border-transparent'
                }`}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={clear}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          >
            Clear Pad
          </button>
        </div>

        <div className="flex gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 min-h-[44px] rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-700 dark:text-slate-200"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!hasInk}
            onClick={() => onSave(canvasRef.current!.toDataURL('image/png'))}
            className="flex-1 min-h-[44px] rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-40"
          >
            Use Signature
          </button>
        </div>
      </div>
    </div>
  );
};
