export type NavTab = 'home' | 'tools' | 'files' | 'settings';

export type ToolId =
  | 'image-to-pdf'
  | 'scanner'
  | 'editor'
  | 'compressor'
  | 'merge'
  | 'split'
  | 'pdf-to-image'
  | 'word-to-pdf'
  | 'excel-to-pdf'
  | 'ppt-to-pdf'
  | 'signature'
  | 'password'
  | 'pdf-to-word'
  | 'jpg-to-pdf'
  | 'png-to-pdf';

export type PageSizePreset = 'A4' | 'A3' | 'Letter' | 'Custom';
export type PageOrientation = 'portrait' | 'landscape';
export type CompressionLevel = 'low' | 'medium' | 'high';
export type ImageFilter = 'original' | 'grayscale' | 'bw' | 'enhance';
export type LanguageCode = 'en' | 'es' | 'fr' | 'de' | 'ar' | 'hi';

export interface StoredFile {
  id: string;
  name: string;
  size: number;
  pageCount: number;
  category: 'created' | 'downloaded';
  mimeType: string;
  data: Uint8Array;
  createdAt: number;
  lastOpenedAt: number;
  isEncrypted?: boolean;
  sourceTool?: string;
}

export interface AppSettings {
  theme: 'light' | 'dark';
  language: LanguageCode;
  defaultPageSize: PageSizePreset;
  defaultOrientation: PageOrientation;
  defaultCompression: CompressionLevel;
  storagePreference: 'device-indexeddb' | 'ask-every-time';
  admobEnabled: boolean;
  admobMode: 'production' | 'test';
  admobAppId: string;
  admobBannerId: string;
  admobInterstitialId: string;
  admobRewardedId: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}

export interface CropRect {
  x: number; // 0..1 normalized
  y: number; // 0..1 normalized
  w: number; // 0..1 normalized
  h: number; // 0..1 normalized
}

export interface ImageItem {
  id: string;
  name: string;
  originalDataUrl: string;
  processedDataUrl: string;
  rotation: number; // 0, 90, 180, 270
  filter: ImageFilter;
  crop: CropRect;
  width: number;
  height: number;
}

export interface Point2D {
  x: number; // 0..1 normalized
  y: number; // 0..1 normalized
}

export interface ScannedPage {
  id: string;
  rawDataUrl: string;
  processedDataUrl: string;
  corners: [Point2D, Point2D, Point2D, Point2D]; // TL, TR, BR, BL
  filter: ImageFilter;
  width: number;
  height: number;
}

export type EditorToolMode = 'select' | 'text' | 'highlight' | 'draw' | 'image' | 'signature';

export interface PdfAnnotation {
  id: string;
  pageIndex: number; // original page index or id reference
  type: 'text' | 'highlight' | 'draw' | 'image' | 'signature';
  x: number; // 0..1 normalized
  y: number; // 0..1 normalized
  width?: number; // 0..1 normalized
  height?: number; // 0..1 normalized
  text?: string;
  fontSize?: number;
  color?: string;
  points?: Point2D[]; // normalized 0..1 for freehand draw
  strokeWidth?: number;
  imageDataUrl?: string;
}

export interface EditorPageState {
  id: string;
  originalIndex: number; // 0-based index in source PDF
  rotation: number; // additional degrees: 0, 90, 180, 270
  thumbnailUrl: string;
  width: number;
  height: number;
}
