# Android APK & AAB Build Instructions — Smart PDF Maker

Smart PDF Maker runs 100% locally on-device with no cloud document uploads. You can package the web bundle directly into a native Android APK / Play Store AAB using Capacitor and Android Studio.

## Prerequisites
- Node.js 20+
- Java JDK 17 or 21
- Android Studio (with Android SDK Platform 34+ & Build-Tools)

## 1. Build the Web Assets
```bash
npm install
npm run build
```

## 2. Add the Android Native Project (Capacitor)
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
```

## 3. Configure Android Permissions & Production AdMob App ID
1. Create a `.env` file (based on `.env.example`) with your real AdMob IDs from https://admob.google.com before running `npm run build`:
   ```env
   VITE_ADMOB_APP_ID="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"
   VITE_ADMOB_BANNER_ID="ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY"
   VITE_ADMOB_INTERSTITIAL_ID="ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY"
   VITE_ADMOB_REWARDED_ID="ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY"
   ```
   *(Or enter them directly in the app under **Settings → Google AdMob Ads**.)*
2. In `android/app/src/main/AndroidManifest.xml`, add camera permission inside `<manifest>` and your **Production AdMob App ID** inside `<application>`:
```xml
<uses-permission android:name="android.permission.CAMERA" />
```
Inside `<application ...>`:
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY" />
```
*(Replace `ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY` with your real AdMob App ID; for testing only, use Google's test App ID `ca-app-pub-3940256099942544~3347511713`.)*

## 4. Build Debug APK (for direct device testing)
```bash
cd android
./gradlew assembleDebug
```
Output APK:
`android/app/build/outputs/apk/debug/app-debug.apk`

## 5. Build Signed Release APK / Play Store AAB
1. Generate an upload keystore (one-time):
   ```bash
   keytool -genkey -v -keystore smart-pdf-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias smartpdf
   ```
2. Open the `android/` folder in **Android Studio**, choose **Build > Generate Signed Bundle / APK**, select your `.jks` keystore, and choose **APK** or **Android App Bundle (AAB)**.
3. Or build via Gradle CLI after configuring `signingConfigs` in `android/app/build.gradle`:
   ```bash
   cd android
   ./gradlew assembleRelease
   ./gradlew bundleRelease
   ```
   Output APK: `android/app/build/outputs/apk/release/app-release.apk`
   Output AAB: `android/app/build/outputs/bundle/release/app-release.aab`
