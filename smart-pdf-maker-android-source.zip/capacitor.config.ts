const config = {
  appId: 'com.smartpdfmaker.app',
  appName: 'Smart PDF Maker',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
  },
};

export default config;
