import fs from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';

const ROOT = process.cwd();
const OUT_FILE = path.join(ROOT, 'public', 'smart-pdf-maker-android-source.zip');

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.gradle',
  'build',
  '.idea',
]);

const EXCLUDED_FILES = new Set([
  'smart-pdf-maker-android-source.zip',
  '.env',
]);

function walk(dir, zip, relBase = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (EXCLUDED_DIRS.has(entry.name)) continue;
    if (EXCLUDED_FILES.has(entry.name)) continue;
    const fullPath = path.join(dir, entry.name);
    const relPath = relBase ? `${relBase}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      walk(fullPath, zip, relPath);
    } else if (entry.isFile()) {
      const content = fs.readFileSync(fullPath);
      const isExecutable = entry.name === 'gradlew';
      zip.file(relPath, content, isExecutable ? { unixPermissions: '755' } : undefined);
    }
  }
}

async function main() {
  const zip = new JSZip();
  walk(ROOT, zip);
  const buf = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
    platform: 'UNIX',
  });
  fs.writeFileSync(OUT_FILE, buf);
  console.log(`Created ${OUT_FILE} (${(buf.byteLength / 1024).toFixed(1)} KB)`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
